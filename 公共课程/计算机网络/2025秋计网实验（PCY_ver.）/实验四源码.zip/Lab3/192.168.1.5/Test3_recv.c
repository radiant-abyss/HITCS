// receiver.c
#include "utils1.h"

#define RECEIVER_MAC MAC_C_BYTES
#define RECEIVER_IP FINAL_DST_IP_STR

int main() {
    int sd;
    unsigned char buffer[65536];
    struct sockaddr_ll sll;
    
    unsigned char receiver_mac[6] = RECEIVER_MAC; // 接收者 MAC
    unsigned int target_src_ip_addr = inet_addr(FINAL_SRC_IP_STR); // 源 IP: 192.168.1.1
    unsigned int target_dst_ip_addr = inet_addr(RECEIVER_IP); // 目的 IP: 192.168.1.5
    unsigned short target_dst_port = htons(DST_PORT);      // 目标目的端口

    // 1. 创建接收原始套接字
    sd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sd < 0) {
        perror("socket error");
        return 1;
    }
    
    printf("Host C (Receiver: %s) is listening on %s for IP datagrams...\n", RECEIVER_IP, IFNAME);

    // 主循环: 接收 -> 检查 -> 打印
    while (1) {
        socklen_t sll_len = sizeof(sll);
        int len = recvfrom(sd, buffer, 65536, 0, (struct sockaddr*)&sll, &sll_len);
        if (len <= 0) {
            continue;
        }

        struct ethhdr *eth = (struct ethhdr *)buffer;
        
        //  过滤 (Filtering) 
        // 1. 过滤非 IPv4 帧 或 目的 MAC 不匹配
        if (ntohs(eth->h_proto) != ETH_P_IP || memcmp(eth->h_dest, receiver_mac, 6) != 0) {
            continue;
        }
        
        struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
        
        // 2. 过滤 IP 地址不匹配 (源/目的) 或 非 UDP 协议
        if (iph->daddr != target_dst_ip_addr || iph->saddr != target_src_ip_addr || iph->protocol != IPPROTO_UDP) {
            continue;
        }

        // 3. 过滤目的端口不匹配
        if (len < sizeof(struct ethhdr) + iph->ihl * 4 + sizeof(struct udphdr)) {
            continue;
        }
        struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4);
        if (udph->dest != target_dst_port) {
            continue;
        }

        // 4. 展示收到数据报信息
        print_packet_info(buffer, len, "Host C (Receiver) - Matched and Accepted");
        
        printf("Host C: Datagram successfully received and processed.\n");
    }

    close(sd);
    return 0;
}