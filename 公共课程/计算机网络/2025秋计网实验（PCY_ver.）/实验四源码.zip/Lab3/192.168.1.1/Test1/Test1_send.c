#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h> 

void getFormattedTime(char* buffer, size_t buf_size) {
    time_t rawtime;
    struct tm *timeinfo;

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, buf_size, "%Y-%m-%d %H:%M:%S", timeinfo);
}


int main() {
    int sockfd;
    struct sockaddr_in dest_addr;
    char buffer[1024]; 
    int port = 12345;  

    const char *HOST_B_IP = "192.168.1.2"; 

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        perror("socket");
        return 1;
    }

    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(port);
    dest_addr.sin_addr.s_addr = inet_addr(HOST_B_IP);

    printf("UDP Sender (Host A: 192.168.1.1) is running.\n");
    printf("Sending to Host B (%s:%d). Type 'exit' to quit:\n", HOST_B_IP, port);

    while (1) {
        printf("> ");
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            break; 
        }

        buffer[strcspn(buffer, "\n")] = 0;

        if (strcmp(buffer, "exit") == 0) {
            printf("Exiting sender...\n");
            break;
        }

        if (sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&dest_addr,
                   sizeof(dest_addr)) < 0) {
            perror("sendto");
        } else {
            char time_buffer[80];
            memset(time_buffer, 0, sizeof(time_buffer));
            getFormattedTime(time_buffer, sizeof(time_buffer));
            printf("[%s] Message sent: \"%s\"\n", time_buffer, buffer);
        }
    }

    close(sockfd);
    return 0;
}
