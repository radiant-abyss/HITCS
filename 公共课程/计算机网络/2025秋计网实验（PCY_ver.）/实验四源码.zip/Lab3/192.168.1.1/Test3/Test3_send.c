#include "utils1.h"

int main() {
    int sd;
    while(1)
    {
        unsigned char buffer[1024];
        struct ethhdr *eth = (struct ethhdr *)buffer;
        struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
        struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
        char *data = (char *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr));
    
        struct sockaddr_ll sll;
        struct ifreq ifr;
        
        unsigned char src_mac[6]; 
        unsigned char dest_mac[6] = MAC_R1_BYTES; // 帧目标：Router R1 的 MAC (第一跳)
        
        const char *target_ip = FINAL_DST_IP_STR;
        
        char message[1024];
        printf("> ");
        if (fgets(message, sizeof(message), stdin) == NULL) {
            break; 
        }

        buffer[strcspn(message, "\n")] = 0;

        if (strcmp(message, "exit\n") == 0) {
            printf("Exiting sender...\n");
            break;
        }
        int payload_len = strlen(message);
    
        
        int total_len = sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + payload_len;
    
        // 1. 创建原始套接字 (Create Raw Socket)
        sd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));
        if (sd < 0) {
            perror("socket error");
            return 1;
        }
    
        // 获取接口索引和源 MAC 地址 (Get Interface Index and Source MAC)
        memset(&ifr, 0, sizeof(ifr));
        strncpy(ifr.ifr_name, IFNAME, IFNAMSIZ - 1);
        if (ioctl(sd, SIOCGIFINDEX, &ifr) < 0) {
            perror("ioctl SIOCGIFINDEX error");
            close(sd);
            return 1;
        }
        sll.sll_ifindex = ifr.ifr_ifindex;
        
        if (ioctl(sd, SIOCGIFHWADDR, &ifr) < 0) {
            perror("ioctl SIOCGIFHWADDR error");
            close(sd);
            return 1;
        }
        memcpy(src_mac, ifr.ifr_hwaddr.sa_data, 6);
    
        // 2. 构造数据报 (Construct Packet)
        memset(buffer, 0, 1024);
        
        //  2.1. UDP Header (传输层) 
        udph->source = htons(SRC_PORT);
        udph->dest = htons(DST_PORT); 
        udph->len = htons(sizeof(struct udphdr) + payload_len);
        udph->check = 0; 
        strcpy(data, message); // 载荷
    
        //  2.2. IP Header (网络层) 
        iph->ihl = 5;       
        iph->version = 4;   
        iph->tos = 0;       
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + payload_len);
        iph->id = htons(rand()); 
        iph->frag_off = 0;  
        iph->ttl = 64;      // 初始 TTL
        iph->protocol = IPPROTO_UDP;
        iph->saddr = inet_addr(FINAL_SRC_IP_STR); // 源 IP: 192.168.1.1
        iph->daddr = inet_addr(target_ip); // 目的 IP: 192.168.1.5
        iph->check = 0;
        iph->check = csum((unsigned short *)iph, sizeof(struct iphdr) / 2); // 计算 IP 校验和
    
        //  2.3. MAC Frame Header (数据链路层) 
        memcpy(eth->h_source, src_mac, 6);     // 源 MAC: Host A's MAC
        memcpy(eth->h_dest, dest_mac, 6);      // 目的 MAC: Router R1's MAC (下一跳)
        eth->h_proto = htons(ETH_P_IP);        // 协议类型: IP
    
        // 3. 准备发送地址信息 (Prepare Socket Address)
        sll.sll_family = AF_PACKET;
        sll.sll_halen = ETH_ALEN;
        sll.sll_protocol = htons(ETH_P_IP);
        memcpy(sll.sll_addr, dest_mac, 6); 
    
        // 4. 发送数据 (Send Packet)
        if (sendto(sd, buffer, total_len, 0, (struct sockaddr*)&sll, sizeof(sll)) < 0) {
            perror("sendto error");
            return 1;
        }
    
        printf("Host A (Sender) Status:\n");
        printf("Datagram sent successfully.\n");
        printf("IP Header: %s -> %s\n", FINAL_SRC_IP_STR, target_ip);
        printf("Next Hop MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
            dest_mac[0],dest_mac[1],dest_mac[2],dest_mac[3],dest_mac[4],dest_mac[5]);

    }

    close(sd);
    return 0;
}