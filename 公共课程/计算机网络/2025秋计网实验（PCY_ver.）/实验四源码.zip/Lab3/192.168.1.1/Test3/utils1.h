
#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <arpa/inet.h>
#include <linux/if_packet.h>

#define IFNAME "ens33"
#define SRC_PORT 54321
#define DST_PORT 12345 

// IP 数据报头中不变的源/目的 IP 地址 (多跳路径)
#define FINAL_SRC_IP_STR "192.168.1.1" // Host A (发送者) IP
#define FINAL_DST_IP_STR "192.168.1.5" // Host C (接收者) IP

// 宏定义所有主机的 MAC 地址 (请务必替换为您实际环境中的 MAC)
#define MAC_A_BYTES {0x00, 0x0C, 0x29, 0x14, 0x13, 0x10}     // Host A
#define MAC_R1_BYTES {0x00, 0x0C, 0x29, 0xA8, 0xD2, 0x95}   // Router 1 (第一跳)
#define MAC_R2_BYTES {0x00, 0x0C, 0x29, 0xBB, 0x20, 0xCA}   // Router 2 (第二跳)
#define MAC_R3_BYTES {0x00, 0x0C, 0x29, 0xC4, 0x70, 0x29}   // Router 3 (第三跳)
#define MAC_C_BYTES {0x00, 0x0C, 0x29, 0xF7, 0xE0, 0x88}     // Host C (终点)

// --- 路由表结构定义 (Routing Table Structure Definition) ---
typedef struct {
    char dest_ip[16];           // 目的IP地址 (Destination IP)
    unsigned char next_hop_mac[6]; // 下一跳MAC地址 (Next Hop MAC)
    char interface[IFNAMSIZ];   // 出口接口 (Outgoing Interface, 简化方案中统一为 IFNAME)
} RoutingEntry;

// IP 头部校验和计算函数 (Checksum function)
unsigned short csum(unsigned short *buf, int nwords) {
    unsigned long sum;
    for (sum = 0; nwords > 0; nwords--)
        sum += *buf++;
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}

// 打印收到的数据报详细信息的函数 (输出使用英文)
void print_packet_info(unsigned char* buffer, int size, const char* role) {
    // 检查 IP 头部长度，防止越界
    struct ethhdr *eth = (struct ethhdr *)buffer;
    if (ntohs(eth->h_proto) != ETH_P_IP || size < sizeof(struct ethhdr) + sizeof(struct iphdr)) {
        return; 
    }
    
    struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
    int ip_header_len = iph->ihl * 4;
    
    // 检查 UDP 头部长度
    if (iph->protocol != IPPROTO_UDP || size < sizeof(struct ethhdr) + ip_header_len + sizeof(struct udphdr)) {
        return; 
    }
    struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + ip_header_len);
    
    // 时间戳
    time_t timer;
    char buffer_time[26];
    struct tm* tm_info;
    time(&timer);
    tm_info = localtime(&timer);
    strftime(buffer_time, 26, "%Y-%m-%d %H:%M:%S", tm_info);

    struct sockaddr_in source, dest;
    memset(&source, 0, sizeof(source));
    source.sin_addr.s_addr = iph->saddr;
    memset(&dest, 0, sizeof(dest));
    dest.sin_addr.s_addr = iph->daddr;
    
    char *data = (char *)(buffer + sizeof(struct ethhdr) + ip_header_len + sizeof(struct udphdr));
    int data_len = ntohs(udph->len) - sizeof(struct udphdr);
    
    printf("\n--- %s: IP Datagram Captured (Time: %s) ---\n", role, buffer_time);
    
    printf("Ethernet Frame Header:\n");
    printf("  Destination MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
        eth->h_dest[0], eth->h_dest[1], eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
    printf("  Source MAC:      %02X:%02X:%02X:%02X:%02X:%02X\n", 
        eth->h_source[0], eth->h_source[1], eth->h_source[2], eth->h_source[3], eth->h_source[4], eth->h_source[5]);
    printf("  EtherType:       0x%04X (IP)\n", ntohs(eth->h_proto));

    printf("IP Header:\n");
    printf("Src IP: %s\n", inet_ntoa(source.sin_addr));
    printf("Dst IP: %s\n", inet_ntoa(dest.sin_addr));
    printf("TTL: %d\n", iph->ttl);
    printf("Length: %d bytes\n", ntohs(iph->tot_len));
    printf("Protocol: %d (UDP)\n", iph->protocol);
    printf("Checksum: 0x%04X\n", ntohs(iph->check));

    printf("UDP Header:\n");
    printf("Src Port: %d\n", ntohs(udph->source));
    printf("Dst Port: %d\n", ntohs(udph->dest));
    
    printf("Payload (Data):\n");
    printf("Message: '%.*s'\n", data_len, data);
    printf("----------------------------------------------------\n");
}

#endif // UTILS_H