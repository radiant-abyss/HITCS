#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define HOST_A_IP "192.168.1.1"
#define PORT_A 54321
#define HOST_C_IP "192.168.2.2"
#define PORT_C 12345

int main() {
    int sd;
    struct sockaddr_in serv_addr, cli_addr;
    char buffer[1024];
    
    // 1. 创建 UDP 套接字
    sd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sd < 0) {
        perror("socket error");
        return 1;
    }

    // 2. 绑定到 Host A 的 IP 和端口
    memset(&cli_addr, 0, sizeof(cli_addr));
    cli_addr.sin_family = AF_INET;
    cli_addr.sin_port = htons(PORT_A);
    cli_addr.sin_addr.s_addr = inet_addr(HOST_A_IP);

    if (bind(sd, (struct sockaddr*)&cli_addr, sizeof(cli_addr)) < 0) {
        perror("bind error");
        close(sd);
        return 1;
    }
    
    printf("Host A (%s:%d) is online.\n", HOST_A_IP, PORT_A);

    // 3. 准备目标地址 (Host C)
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT_C);
    serv_addr.sin_addr.s_addr = inet_addr(HOST_C_IP);
    // 4. 发送消息
    while(1)
    {
        printf("> ");
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            break; 
        }

        buffer[strcspn(buffer, "\n")] = 0;

        if (strcmp(buffer, "exit") == 0) {
            printf("Exiting sender...\n");
        }

        if (sendto(sd, buffer, strlen(buffer), 0, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
            perror("sendto error");
            close(sd);
            return 1;
        }
        printf("Host A: Sent message to %s: '%s'\n", HOST_C_IP, buffer);
        
        // 5. 等待回复
        printf("Host A: Waiting for reply...\n");
        socklen_t len = sizeof(serv_addr);
        int n = recvfrom(sd, buffer, 1024, 0, (struct sockaddr*)&serv_addr, &len);
        if (n < 0) {
            perror("recvfrom error");
            close(sd);
            return 1;
        }
    
        buffer[n] = '\0';
        printf("Host A: Received reply from %s: '%s'\n", inet_ntoa(serv_addr.sin_addr), buffer);
        
    }
    
    close(sd);
    return 0;
}