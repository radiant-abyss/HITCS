#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h> 

void getFormattedTime(char* buffer, size_t buf_size) {
    time_t rawtime;
    struct tm *timeinfo;

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, buf_size, "%Y-%m-%d %H:%M:%S", timeinfo);
}

int main() {
    int sockfd;
    struct sockaddr_in src_addr, dest_addr, my_addr;
    char buffer[1024];
    socklen_t addr_len;

    int src_port = 12345;  
    int dest_port = 54321; 

    const char *HOST_C_IP = "192.168.1.3";

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        perror("socket");
        return 1;
    }

    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(src_port);
    my_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(my_addr)) < 0) {
        perror("bind");
        return 1;
    }

    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(dest_port);
    dest_addr.sin_addr.s_addr = inet_addr(HOST_C_IP);

    printf("UDP Forwarder (Host B: 192.168.1.2) listening on port %d...\n", src_port);
    printf("Will forward to Host C (%s:%d).\n", HOST_C_IP, dest_port);

    while (1) {
        addr_len = sizeof(src_addr);
        int recv_len = recvfrom(sockfd, buffer, sizeof(buffer) - 1, 0, (struct sockaddr *)&src_addr, &addr_len);

        if (recv_len < 0) {
            perror("recvfrom");
            continue; 
        }

        buffer[recv_len] = '\0';
        char time_buffer[80];
        memset(time_buffer, 0, sizeof(time_buffer));
        getFormattedTime(time_buffer, sizeof(time_buffer));
        printf("[%s] Received from %s: \"%s\". Forwarding to Host C...\n", time_buffer, inet_ntoa(src_addr.sin_addr), buffer);
        
        if (sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&dest_addr,
                   sizeof(dest_addr)) < 0) {
            perror("sendto");
        } else {
            printf("Datagram forwarded.\n");
        }
    }

    close(sockfd);
    return 0;
}
