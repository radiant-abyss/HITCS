// router.c
#include "utils.h"

#define MAC_R_ACTUAL MAC_R_BYTES

int main() {
    int sd_recv, sd_send;
    unsigned char buffer[65536];
    struct sockaddr_ll sll_recv, sll_send;
    struct ifreq ifr;
    
    unsigned char router_mac[6] = MAC_R_ACTUAL;      // 路由器 MAC
    unsigned char receiver_mac[6] = MAC_C_BYTES;     // 接收者 C 的 MAC (下一跳)
    unsigned int target_src_ip_addr = inet_addr(SRC_IP_STR); // 目标源 IP 地址
    unsigned int target_dst_ip_addr = inet_addr(DST_IP_STR); // 目标目的 IP 地址
    unsigned short target_dst_port = htons(DST_PORT);      // 目标目的端口

    // 1. 创建接收原始套接字 (Create Raw Socket for Receiving)
    sd_recv = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sd_recv < 0) {
        perror("socket(recv) error");
        return 1;
    }
    
    // 2. 创建发送原始套接字 (Create Raw Socket for Sending)
    sd_send = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));
    if (sd_send < 0) {
        perror("socket(send) error");
        close(sd_recv);
        return 1;
    }

    // 获取接口索引 (Get Interface Index for sending)
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, IFNAME, IFNAMSIZ - 1);
    if (ioctl(sd_send, SIOCGIFINDEX, &ifr) < 0) {
        perror("ioctl SIOCGIFINDEX error");
        close(sd_recv);
        close(sd_send);
        return 1;
    }
    sll_send.sll_ifindex = ifr.ifr_ifindex;
    
    printf("Host R (Router) is listening on %s for IP datagrams...\n", IFNAME);

    // 主循环: 接收 -> 检查 -> 转发
    while (1) {
        socklen_t sll_len = sizeof(sll_recv);
        int len = recvfrom(sd_recv, buffer, 65536, 0, (struct sockaddr*)&sll_recv, &sll_len);
        if (len <= 0) {
            continue;
        }

        struct ethhdr *eth = (struct ethhdr *)buffer;
        
        //  过滤 (Filtering) 
        // 1. 过滤非 IPv4 帧 或 目的 MAC 不匹配
        if (ntohs(eth->h_proto) != ETH_P_IP || memcmp(eth->h_dest, router_mac, 6) != 0) {
            continue;
        }
        
        struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));

        // 2. 过滤 IP 地址不匹配 或 非 UDP 协议
        if (iph->daddr != target_dst_ip_addr || iph->saddr != target_src_ip_addr || iph->protocol != IPPROTO_UDP) {
            continue;
        }

        // 检查 UDP 头部长度
        if (len < sizeof(struct ethhdr) + iph->ihl * 4 + sizeof(struct udphdr)) {
            continue;
        }
        struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4);
        
        // 3. 过滤目的端口不匹配
        if (udph->dest != target_dst_port) {
            continue;
        }
        
        // 1. 展示收到数据报信息 (Display Received Packet Info)
        print_packet_info(buffer, len, "Host R (Router) - Datagram Received");
        
        //  IP 数据报转发逻辑 (IP Data Forwarding Logic) 
        
        //  (新增) 展示修改前的数据报关键信息 
        printf("\n Host R: Processing Changes BEFORE Forwarding \n");
        printf("  Current TTL: %d\n", iph->ttl);
        printf("  Current Src MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
            eth->h_source[0], eth->h_source[1], eth->h_source[2], eth->h_source[3], eth->h_source[4], eth->h_source[5]);
        printf("  Current Dst MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
            eth->h_dest[0], eth->h_dest[1], eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
        printf("-\n");
        
        // 2. 执行 IP 头部修改
        if (iph->ttl <= 1) {
            printf("WARNING: TTL <= 1, Datagram Dropped.\n");
            continue;
        }
        
        unsigned short old_checksum = iph->check;
        
        iph->ttl--;       // TTL 减 1 (Decrement TTL)
        iph->check = 0;   // 清零校验和 (Reset Checksum)
        iph->check = csum((unsigned short *)iph, iph->ihl * 2); // 重新计算 IP 校验和 (Recalculate Checksum)
        
        // 3. 重新构造 MAC 帧头部
        memcpy(eth->h_source, router_mac, 6);   // 新的源 MAC: 路由器 R 的 MAC
        memcpy(eth->h_dest, receiver_mac, 6);   // 新的目的 MAC: 接收者 C 的 MAC

        //  (新增) 展示修改后的数据报关键信息 
        printf("\n Host R: Modifications Completed \n");
        printf("  TTL Changed: %d -> %d\n", iph->ttl + 1, iph->ttl);
        printf("  Checksum Changed: 0x%04X -> 0x%04X\n", ntohs(old_checksum), ntohs(iph->check));
        printf("  New Src MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
            eth->h_source[0], eth->h_source[1], eth->h_source[2], eth->h_source[3], eth->h_source[4], eth->h_source[5]);
        printf("  New Dst MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
            eth->h_dest[0], eth->h_dest[1], eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
        printf("\n");
        
        // 4. 发送转发后的数据报
        sll_send.sll_family = AF_PACKET;
        sll_send.sll_halen = ETH_ALEN;
        sll_send.sll_protocol = htons(ETH_P_IP);
        memcpy(sll_send.sll_addr, receiver_mac, 6);

        if (sendto(sd_send, buffer, len, 0, (struct sockaddr*)&sll_send, sizeof(sll_send)) < 0) {
            perror("sendto error");
            continue;
        }
        printf("Host R: Forwarding successful!\n");
    }

    close(sd_recv);
    close(sd_send);
    return 0;
}