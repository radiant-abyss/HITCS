#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <arpa/inet.h>
#include <linux/if_packet.h>

// --- 全局网络配置参数 (Global Network Configuration Parameters) ---

#define IFNAME "ens33"

// IP 数据报头中不变的源/目的 IP 地址
#define SRC_IP_STR "192.168.1.1"
#define DST_IP_STR "192.168.1.3"

// 默认的源/目的端口
#define SRC_PORT 54321
#define DST_PORT 12345

#define MAC_R_BYTES {0x00, 0x0C, 0x29, 0xA8, 0xD2, 0x95}
#define MAC_C_BYTES {0x00, 0x0C, 0x29, 0xBB, 0x20, 0xCA}

//IP校验和
unsigned short csum(unsigned short *buf, int nwords) {
    unsigned long sum;
    for (sum = 0; nwords > 0; nwords--)
        sum += *buf++;
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}

// 打印信息函数
void print_packet_info(unsigned char* buffer, int size, const char* role) {
    struct ethhdr *eth = (struct ethhdr *)buffer;
    // 检查是否小于数据报最小大小
    if (size < sizeof(struct ethhdr) + sizeof(struct iphdr)) {
        printf("ERROR: Received packet size is too small.\n");
        return;
    }
    struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
    
    // Check minimum size for UDP header
    if (size < sizeof(struct ethhdr) + iph->ihl * 4 + sizeof(struct udphdr)) {
        printf("ERROR: Received packet size is too small for UDP.\n");
        return;
    }
    struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4);
    
    // Timestamp
    time_t timer;
    char buffer_time[26];
    struct tm* tm_info;
    time(&timer);
    tm_info = localtime(&timer);
    strftime(buffer_time, 26, "%Y-%m-%d %H:%M:%S", tm_info);

    struct sockaddr_in source, dest;
    memset(&source, 0, sizeof(source));
    source.sin_addr.s_addr = iph->saddr;
    memset(&dest, 0, sizeof(dest));
    dest.sin_addr.s_addr = iph->daddr;
    
    char *data = (char *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4 + sizeof(struct udphdr));
    int data_len = ntohs(udph->len) - sizeof(struct udphdr);
    
    printf("\n--- %s: IP Datagram Received (Time: %s) ---\n", role, buffer_time);
    
    printf("Ethernet Frame Header\n");
    printf("MAC | Src: %02X:%02X:%02X:%02X:%02X:%02X\n", 
        eth->h_source[0], eth->h_source[1], eth->h_source[2], eth->h_source[3], eth->h_source[4], eth->h_source[5]);
    printf("MAC | Dst: %02X:%02X:%02X:%02X:%02X:%02X\n", 
        eth->h_dest[0], eth->h_dest[1], eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
    printf("EtherType: 0x%04X (IP)\n", ntohs(eth->h_proto));
    printf("IP  | Src: %s\n", inet_ntoa(source.sin_addr));
    printf("IP  | Dst: %s\n", inet_ntoa(dest.sin_addr));
    printf("Len : %d bytes\n", ntohs(iph->tot_len));
    printf("TTL : %d\n", iph->ttl);
    printf("Ptl : %d (UDP)\n", iph->protocol);
    printf("Csum: 0x%04X\n", ntohs(iph->check));
    printf("Port| Src: %d\n", ntohs(udph->source));
    printf("Port| Dst: %d\n", ntohs(udph->dest));
    
    printf("Payload (Data):\n");
    printf("Message:'%.*s'\n", data_len, data);
    printf("--------------------------------------\n");
}

#endif // UTILS_H