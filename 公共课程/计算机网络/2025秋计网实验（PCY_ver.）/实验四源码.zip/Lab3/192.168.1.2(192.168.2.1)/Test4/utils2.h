// utils.h

#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/select.h> // 用于 select()
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <arpa/inet.h>
#include <linux/if_packet.h>

// --- 全局网络配置参数 (Global Network Configuration Parameters) ---

#define IFNAME_1 "ens33"
// 路由器 R 的 eth1
#define IFNAME_2 "ens37"

// 端口配置 (用于过滤)
#define PORT_A 54321 // Host A 监听的端口
#define PORT_C 12345 // Host C 监听的端口

// IP 地址配置
#define HOST_A_IP "192.168.136.128"
#define ROUTER_R1_IP "192.168.136.129" // Router (eth0) IP
#define ROUTER_R2_IP "192.168.2.1" // Router (eth1) IP
#define HOST_C_IP "192.168.2.2"

// MAC 地址配置 (*** 必须替换为您的实际 MAC 地址 ***)
#define MAC_A_BYTES {0x00, 0x0C, 0x29, 0x14, 0x13, 0x10}     // Host A
#define MAC_R1_BYTES {0x00, 0x0C, 0x29, 0xA8, 0xD2, 0x95}   // Router (eth0)
#define MAC_R2_BYTES {0x00, 0x0C, 0x29, 0xA8, 0xD2, 0x9F}   // Router (eth1)
#define MAC_C_BYTES {0x00, 0x0c, 0x29, 0xBB, 0x20, 0xD4}     // Host C

// --- 路由表和 ARP 表结构 ---

// 路由表项：根据目的网络 IP 查找下一跳 IP 和出口
typedef struct {
    char dest_net[16];          // 目的网络 (e.g., "192.168.2.0")
    char netmask[16];           // 子网掩码 (e.g., "255.255.255.0")
    char next_hop_ip[16];       // 下一跳 IP (如果是直连，则为 "0.0.0.0")
    char interface[IFNAMSIZ];   // 出口接口 (e.g., IFNAME_2)
} RoutingEntry;

// ARP 表项 (模拟)：根据 IP 查找 MAC 地址
typedef struct {
    char ip_addr[16];
    unsigned char mac_addr[6];
} ArpEntry;

// IP 头部校验和计算函数 (Checksum function)
unsigned short csum(unsigned short *buf, int nwords) {
    unsigned long sum;
    for (sum = 0; nwords > 0; nwords--)
        sum += *buf++;
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}

// 打印数据报详细信息 (满足验收要求)
void print_packet_info(unsigned char* buffer, int size, const char* role) {
    struct ethhdr *eth = (struct ethhdr *)buffer;
    if (ntohs(eth->h_proto) != ETH_P_IP) return;
    struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
    if (iph->protocol != IPPROTO_UDP) return;
    struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4);
    
    // 时间戳
    time_t timer;
    char buffer_time[26];
    struct tm* tm_info;
    time(&timer);
    tm_info = localtime(&timer);
    strftime(buffer_time, 26, "%Y-%m-%d %H:%M:%S", tm_info);

    struct sockaddr_in source, dest;
    memset(&source, 0, sizeof(source));
    source.sin_addr.s_addr = iph->saddr;
    memset(&dest, 0, sizeof(dest));
    dest.sin_addr.s_addr = iph->daddr;
    
    printf("\n--- %s: IP Datagram Captured (Time: %s) ---\n", role, buffer_time);
    
    printf("  L2 - Source MAC:      %02X:%02X:%02X:%02X:%02X:%02X\n", 
        eth->h_source[0], eth->h_source[1], eth->h_source[2], eth->h_source[3], eth->h_source[4], eth->h_source[5]);
    printf("  L2 - Destination MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
        eth->h_dest[0], eth->h_dest[1], eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
    printf("  L3 - Source IP:       %s\n", inet_ntoa(source.sin_addr));
    printf("  L3 - Destination IP:  %s\n", inet_ntoa(dest.sin_addr));
    printf("  L3 - TTL:             %d\n", iph->ttl);
    printf("  L4 - Source Port:     %d\n", ntohs(udph->source));
    printf("  L4 - Destination Port: %d\n", ntohs(udph->dest));
    printf("----------------------------------------------------\n");
}


// 辅助函数：创建并绑定到特定接口的 AF_PACKET 套接字
int create_raw_socket(const char* interface_name, int* if_index_out, unsigned char* mac_out) {
    int sd;
    struct ifreq ifr;
    struct sockaddr_ll sll;

    sd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sd < 0) {
        perror("socket error");
        return -1;
    }

    // 获取接口索引
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, interface_name, IFNAMSIZ - 1);
    if (ioctl(sd, SIOCGIFINDEX, &ifr) < 0) {
        perror("ioctl SIOCGIFINDEX error");
        close(sd);
        return -1;
    }
    *if_index_out = ifr.ifr_ifindex;

    // 获取接口 MAC 地址
    if (ioctl(sd, SIOCGIFHWADDR, &ifr) < 0) {
        perror("ioctl SIOCGIFHWADDR error");
        close(sd);
        return -1;
    }
    memcpy(mac_out, ifr.ifr_hwaddr.sa_data, 6);

    // 绑定套接字到特定接口
    memset(&sll, 0, sizeof(sll));
    sll.sll_family = AF_PACKET;
    sll.sll_ifindex = *if_index_out;
    sll.sll_protocol = htons(ETH_P_ALL);
    if (bind(sd, (struct sockaddr*)&sll, sizeof(sll)) < 0) {
        perror("bind error");
        close(sd);
        return -1;
    }

    return sd;
}

#endif // UTILS_H