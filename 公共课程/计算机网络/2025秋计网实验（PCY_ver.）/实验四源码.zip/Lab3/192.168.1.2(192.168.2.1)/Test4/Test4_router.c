// router_r.c
#include "utils2.h"

//  路由表和 ARP 表配置 

// 静态路由表
RoutingEntry routing_table[] = {
    // 目的网络        子网掩码            下一跳         出口
    {"192.168.1.0", "255.255.255.0", "0.0.0.0", IFNAME_1}, // 直连
    {"192.168.2.0", "255.255.255.0", "0.0.0.0", IFNAME_2}  // 直连
};
const int ROUTING_TABLE_SIZE = 2;

// 静态 ARP 表 (模拟)
ArpEntry arp_table[] = {
    {HOST_A_IP, MAC_A_BYTES},
    {HOST_C_IP, MAC_C_BYTES}
};
const int ARP_TABLE_SIZE = 2;

//  辅助函数 

// 路由表查找 (返回出口接口名称)
const char* route_lookup(unsigned int dest_ip_addr) {
    for (int i = 0; i < ROUTING_TABLE_SIZE; i++) {
        unsigned int net_addr = inet_addr(routing_table[i].dest_net);
        unsigned int mask_addr = inet_addr(routing_table[i].netmask);
        
        if ((dest_ip_addr & mask_addr) == net_addr) {
            return routing_table[i].interface;
        }
    }
    return NULL; // 没有路由
}

// ARP 表查找 (返回下一跳 MAC)
unsigned char* arp_lookup(unsigned int next_hop_ip_addr) {
    struct in_addr addr;
    addr.s_addr = next_hop_ip_addr;
    char ip_str[16];
    strcpy(ip_str, inet_ntoa(addr));

    for (int i = 0; i < ARP_TABLE_SIZE; i++) {
        if (strcmp(arp_table[i].ip_addr, ip_str) == 0) {
            return arp_table[i].mac_addr;
        }
    }
    return NULL; // 没有 MAC
}

//  路由器转发核心逻辑 
void handle_packet(int sd_in, int sd_out, int if_index_out, unsigned char* mac_out, const char* role_name) {
    
    unsigned char buffer[65536];
    int len = recvfrom(sd_in, buffer, 65536, 0, NULL, NULL);
    if (len <= 0) return;

    struct ethhdr *ens = (struct ethhdr *)buffer;
    
    // 1. 过滤 L2 (确保是 IP 包)
    if (ntohs(ens->h_proto) != ETH_P_IP) return;
    
    struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));

    // 2. 路由查找：根据目的 IP 查找路由表
    const char* out_if_name = route_lookup(iph->daddr);
    
    // 3. ARP 查找：查找下一跳 MAC
    // (在直连路由中，下一跳 IP 就是最终目的 IP)
    unsigned char* next_hop_mac = arp_lookup(iph->daddr);

    // 4. 检查是否需要转发 (如果找不到路由或 ARP，则丢弃)
    if (out_if_name == NULL || next_hop_mac == NULL) {
        // printf("%s: No route or ARP entry found. Dropping packet.\n", role_name);
        return;
    }
    
    // 5. 打印详细日志 (满足验收要求) 
    print_packet_info(buffer, len, role_name);

    // 6. 执行转发
    // 检查 TTL
    if (iph->ttl <= 1) {
        printf("%s: WARNING: TTL <= 1, Datagram Dropped.\n", role_name);
        return;
    }

    // 修改 L3 (IP Header)
    iph->ttl--;
    iph->check = 0;
    iph->check = csum((unsigned short *)iph, iph->ihl * 2);

    // 修改 L2 (Ensernet Header)
    memcpy(ens->h_source, mac_out, 6);   // 源 MAC 替换为出口 MAC
    memcpy(ens->h_dest, next_hop_mac, 6); // 目的 MAC 替换为下一跳 MAC

    // 7. 准备发送
    struct sockaddr_ll sll_send;
    memset(&sll_send, 0, sizeof(sll_send));
    sll_send.sll_family = AF_PACKET;
    sll_send.sll_ifindex = if_index_out;
    sll_send.sll_halen = ETH_ALEN;
    sll_send.sll_protocol = htons(ETH_P_IP);
    memcpy(sll_send.sll_addr, next_hop_mac, 6);

    if (sendto(sd_out, buffer, len, 0, (struct sockaddr*)&sll_send, sizeof(sll_send)) < 0) {
        perror("sendto error");
    } else {
        print_packet_info(buffer, len, role_name);
    }
}

//主程序 
int main() {
    int sd1, sd2; // 套接字 1 (ens0) 和 套接字 2 (ens1)
    int if_index1, if_index2;
    unsigned char mac1[6];
    unsigned char mac2[6];

    // 使用辅助函数创建并绑定套接字
    sd1 = create_raw_socket(IFNAME_1, &if_index1, mac1);
    if (sd1 < 0) {
        fprintf(stderr, "Error creating socket for %s\n", IFNAME_1);
        return 1;
    }
    
    sd2 = create_raw_socket(IFNAME_2, &if_index2, mac2);
    if (sd2 < 0) {
        fprintf(stderr, "Error creating socket for %s\n", IFNAME_2);
        return 1;
    }
    
    printf("Router R (Dual-NIC) is online... (Kernel forwarding disabled)\n");
    printf("  Listening on %s (MAC: %02X:%02X:%02X:%02X:%02X:%02X)\n", IFNAME_1, mac1[0], mac1[1], mac1[2], mac1[3], mac1[4], mac1[5]);
    printf("  Listening on %s (MAC: %02X:%02X:%02X:%02X:%02X:%02X)\n", IFNAME_2, mac2[0], mac2[1], mac2[2], mac1[3], mac1[4], mac1[5]);

    // 使用 select() 监听两个套接字
    fd_set read_fds;
    int max_fd = (sd1 > sd2) ? sd1 : sd2;

    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(sd1, &read_fds);
        FD_SET(sd2, &read_fds);

        if (select(max_fd + 1, &read_fds, NULL, NULL, NULL) < 0) {
            perror("select error");
            break;
        }

        // 检查是否从接口 1 (ens0) 收到数据
        if (FD_ISSET(sd1, &read_fds)) {
            // 收到来自 192.168.1.0 子网的数据，转发到 接口 2 (ens1)
            // (mac2 是 ens1 的 MAC, 将作为转发包的源 MAC)
            handle_packet(sd1, sd2, if_index2, mac2, "Router (IF1->IF2)");
        }

        // 检查是否从接口 2 (ens1) 收到数据
        if (FD_ISSET(sd2, &read_fds)) {
            // 收到来自 192.168.2.0 子网的数据，转发到 接口 1 (ens0)
            // (mac1 是 ens0 的 MAC, 将作为转发包的源 MAC)
            handle_packet(sd2, sd1, if_index1, mac1, "Router (IF2->IF1)");
        }
    }

    close(sd1);
    close(sd2);
    return 0;
}
