#include "utils1.h"

// R2 配置
#define ROUTER_MAC MAC_R2_BYTES
#define ROUTER_NAME "Host R2 (Router 2)"
#define NEXT_HOP_MAC MAC_R3_BYTES // 下一跳是 R3

// R2 的转发表：将 FINAL_DST_IP_STR 路由到 R3
RoutingEntry routing_table[] = {
    {FINAL_DST_IP_STR, NEXT_HOP_MAC, IFNAME}
};
const int ROUTING_TABLE_SIZE = sizeof(routing_table) / sizeof(RoutingEntry);

// 路由表查找函数 (Route lookup function)
RoutingEntry* route_lookup(unsigned int dest_ip) {
    char dest_ip_str[16];
    struct in_addr addr;
    addr.s_addr = dest_ip;
    strncpy(dest_ip_str, inet_ntoa(addr), 16);

    for (int i = 0; i < ROUTING_TABLE_SIZE; i++) {
        if (strcmp(routing_table[i].dest_ip, dest_ip_str) == 0) {
            return &routing_table[i];
        }
    }
    return NULL;
}

// 主程序 (Router R2)
int main() {    
    int sd_recv, sd_send;
    unsigned char buffer[65536];
    struct sockaddr_ll sll_recv, sll_send;
    struct ifreq ifr;
    
    unsigned char router_mac[6] = ROUTER_MAC; 
    unsigned int target_src_ip_addr = inet_addr(FINAL_SRC_IP_STR);
    unsigned short target_dst_port = htons(DST_PORT);      

    sd_recv = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    sd_send = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));
    
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, IFNAME, IFNAMSIZ - 1);
    ioctl(sd_send, SIOCGIFINDEX, &ifr);
    sll_send.sll_ifindex = ifr.ifr_ifindex;
    
    printf("%s Loaded Routing Table (%d entries):\n", ROUTER_NAME, ROUTING_TABLE_SIZE);
    //  (打印路由表信息)
    printf("%s is listening on %s...\n", ROUTER_NAME, IFNAME);

    while (1) {
        socklen_t sll_len = sizeof(sll_recv);
        int len = recvfrom(sd_recv, buffer, 65536, 0, (struct sockaddr*)&sll_recv, &sll_len);
        if (len <= 0) {
            continue;
        }

        struct ethhdr *eth = (struct ethhdr *)buffer;
        
        //  过滤 (Filtering)  (与 R1 相同)
        if (ntohs(eth->h_proto) != ETH_P_IP || memcmp(eth->h_dest, router_mac, 6) != 0) { continue; }
        struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
        if (iph->saddr != target_src_ip_addr || iph->protocol != IPPROTO_UDP) { continue; }
        if (len < sizeof(struct ethhdr) + iph->ihl * 4 + sizeof(struct udphdr)) { continue; }
        struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4);
        if (udph->dest != target_dst_port) { continue; }
        
        //  查表转发 
        RoutingEntry* route = route_lookup(iph->daddr);
        if (route == NULL) {
            printf("%s: ERROR: Destination IP %s not found in routing table. Datagram Dropped.\n", ROUTER_NAME, inet_ntoa(*(struct in_addr *)&iph->daddr));
            continue;
        }
        
        print_packet_info(buffer, len, ROUTER_NAME);
        
        //  (新增) 展示修改前后的数据报关键信息 
        printf("\n %s: Processing Changes BEFORE Forwarding (Next Hop: R3) \n", ROUTER_NAME);
        printf("  Current TTL: %d | Checksum: 0x%04X\n", iph->ttl, ntohs(iph->check));
        // ... (print current MAC Dst)

        if (iph->ttl <= 1) { continue; }
        unsigned short old_checksum = iph->check;
        iph->ttl--;       
        iph->check = 0;   
        iph->check = csum((unsigned short *)iph, iph->ihl * 2); 
        
        memcpy(eth->h_source, router_mac, 6);               
        memcpy(eth->h_dest, route->next_hop_mac, 6);        
        
        printf("\n %s: Modifications Completed (Ready to send to R3) \n", ROUTER_NAME);
        printf("  TTL Changed: %d -> %d\n", iph->ttl + 1, iph->ttl);
        printf("  Checksum Changed: 0x%04X -> 0x%04X\n", ntohs(old_checksum), ntohs(iph->check));
        // ... (print new MAC Dst)

        // 4. 发送转发后的数据报
        sll_send.sll_family = AF_PACKET;
        sll_send.sll_halen = ETH_ALEN;
        sll_send.sll_protocol = htons(ETH_P_IP);
        memcpy(sll_send.sll_addr, route->next_hop_mac, 6);

        if (sendto(sd_send, buffer, len, 0, (struct sockaddr*)&sll_send, sizeof(sll_send)) < 0) { continue; }
        printf("%s: Forwarding successful to Dst IP %s!\n", ROUTER_NAME, route->dest_ip);
    }
    close(sd_recv);
    close(sd_send);
    return 0;
}