#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define HOST_C_IP "192.168.2.2"
#define PORT_C 12345

int main() {
    int sd;
    struct sockaddr_in serv_addr, cli_addr;
    char buffer[1024];
    
    // 1. 创建 UDP 套接字
    sd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sd < 0) {
        perror("socket error");
        return 1;
    }

    // 2. 绑定到 Host C 的 IP 和端口
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT_C);
    serv_addr.sin_addr.s_addr = inet_addr(HOST_C_IP);

    if (bind(sd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("bind error");
        close(sd);
        return 1;
    }
    
    printf("Host C (%s:%d) is online. Waiting for message...\n", HOST_C_IP, PORT_C);

    // 3. 循环等待消息
    while (1) {
        socklen_t len = sizeof(cli_addr);
        int n = recvfrom(sd, buffer, 1024, 0, (struct sockaddr*)&cli_addr, &len);
        if (n < 0) {
            perror("recvfrom error");
            continue;
        }

        buffer[n] = '\0';
        printf("Host C: Received message from %s: '%s'\n", inet_ntoa(cli_addr.sin_addr), buffer);

        // 4. 发送回复
        const char* msg_to_a = "Hello! Got your message loud and clear.";
        if (sendto(sd, msg_to_a, strlen(msg_to_a), 0, (struct sockaddr*)&cli_addr, sizeof(cli_addr)) < 0) {
            perror("sendto reply error");
        } else {
            printf("Host C: Sent reply to %s.\n", inet_ntoa(cli_addr.sin_addr));
        }
    }
    
    close(sd);
    return 0;
}