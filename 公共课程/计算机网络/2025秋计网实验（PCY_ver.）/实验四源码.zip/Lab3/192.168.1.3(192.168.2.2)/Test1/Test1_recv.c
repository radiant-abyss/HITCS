#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h> 

void getFormattedTime(char* buffer, size_t buf_size) {
    time_t rawtime;
    struct tm *timeinfo;

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, buf_size, "%Y-%m-%d %H:%M:%S", timeinfo);
}


int main() {
    int sockfd;
    struct sockaddr_in src_addr, my_addr;
    char buffer[1024];
    socklen_t addr_len;
    int port = 54321; 

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        perror("socket");
        return 1;
    }

    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(port);
    my_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(my_addr)) < 0) {
        perror("bind");
        return 1;
    }

    printf("UDP Receiver (Host C: 192.168.1.3) listening on port %d...\n", port);

    while (1) {
        addr_len = sizeof(src_addr);
        int recv_len = recvfrom(sockfd, buffer, sizeof(buffer) - 1, 0, (struct sockaddr *)&src_addr, &addr_len);

        if (recv_len < 0) {
            perror("recvfrom");
            continue; 
        }

        buffer[recv_len] = '\0';
        char time_buffer[80];
        memset(time_buffer, 0, sizeof(time_buffer));
        getFormattedTime(time_buffer, sizeof(time_buffer));
        printf("[%s] Datagram received from %s: \"%s\"\n", time_buffer, inet_ntoa(src_addr.sin_addr), buffer);
    }

    close(sockfd);
    return 0;
}
