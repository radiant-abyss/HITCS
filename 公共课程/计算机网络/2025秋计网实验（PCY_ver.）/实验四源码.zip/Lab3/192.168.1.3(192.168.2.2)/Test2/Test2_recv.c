// receiver.c
#include "utils.h"

#define MAC_C_ACTUAL MAC_C_BYTES

int main() {
    int sd;
    unsigned char buffer[1024];
    struct sockaddr_ll sll;
    
    unsigned char receiver_mac[6] = MAC_C_ACTUAL; // 接收者 MAC
    unsigned int target_src_ip_addr = inet_addr(SRC_IP_STR); // 目标源 IP 地址
    unsigned int target_dst_ip_addr = inet_addr(DST_IP_STR); // 目标目的 IP 地址
    unsigned short target_dst_port = htons(DST_PORT);      // 目标目的端口

    // 1. 创建接收原始套接字 (Create Raw Socket)
    sd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sd < 0) {
        perror("socket error");
        return 1;
    }
    
    printf("Host C (Receiver) is listening on %s for IP datagrams...\n", IFNAME);

    // 主循环: 接收 -> 检查 -> 打印
    while (1) {
        socklen_t sll_len = sizeof(sll);
        int len = recvfrom(sd, buffer, 1024, 0, (struct sockaddr*)&sll, &sll_len);
        if (len <= 0) {
            continue;
        }

        struct ethhdr *eth = (struct ethhdr *)buffer;
        
        //  过滤 (Filtering) 
        // 1. 过滤非 IPv4 帧
        if (ntohs(eth->h_proto) != ETH_P_IP) {
            continue;
        }

        // 2. 过滤非发给接收者 MAC 的帧
        if (memcmp(eth->h_dest, receiver_mac, 6) != 0) {
            continue;
        }
        
        struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
        
        // 3. 过滤非目标 IP (源 IP 和 目的 IP 必须匹配)
        if (iph->daddr != target_dst_ip_addr || iph->saddr != target_src_ip_addr) {
            continue;
        }

        // 4. 过滤非 UDP 协议
        if (iph->protocol != IPPROTO_UDP) {
            continue;
        }

        // 获取 UDP 头部 (Get UDP header)
        if (len < sizeof(struct ethhdr) + iph->ihl * 4 + sizeof(struct udphdr)) {
            continue;
        }
        struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4);
        
        // 5. 过滤非目标端口
        if (udph->dest != target_dst_port) {
            continue;
        }

        // 2. 展示收到数据报信息 (Display Received Packet Info)
        print_packet_info(buffer, len, "Host C (Receiver) - Matched and Accepted");
        
        printf("Host C: Datagram successfully received and processed.\n");
    }

    close(sd);
    return 0;
}