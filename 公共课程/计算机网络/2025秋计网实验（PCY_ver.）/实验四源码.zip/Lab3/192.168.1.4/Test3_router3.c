// router_r3.c
#include "utils1.h"

// R3 配置
#define ROUTER_MAC MAC_R3_BYTES
#define ROUTER_NAME "Host R3 (Router 3)"
#define NEXT_HOP_MAC MAC_C_BYTES // 下一跳是 Host C

// R3 的转发表：将 FINAL_DST_IP_STR 路由到 Host C
RoutingEntry routing_table[] = {
    {FINAL_DST_IP_STR, NEXT_HOP_MAC, IFNAME}
};
const int ROUTING_TABLE_SIZE = sizeof(routing_table) / sizeof(RoutingEntry);

// 路由表查找函数 (Route lookup function)
RoutingEntry* route_lookup(unsigned int dest_ip) {
    char dest_ip_str[16];
    struct in_addr addr;
    addr.s_addr = dest_ip;
    strncpy(dest_ip_str, inet_ntoa(addr), 16);

    for (int i = 0; i < ROUTING_TABLE_SIZE; i++) {
        if (strcmp(routing_table[i].dest_ip, dest_ip_str) == 0) {
            return &routing_table[i];
        }
    }
    return NULL;
}

// 主程序 (Router R3)
int main() {
    int sd_recv, sd_send;
    unsigned char buffer[65536];
    struct sockaddr_ll sll_recv, sll_send;
    struct ifreq ifr;
    
    unsigned char router_mac[6] = ROUTER_MAC; 
    unsigned int target_src_ip_addr = inet_addr(FINAL_SRC_IP_STR);
    unsigned short target_dst_port = htons(DST_PORT);      

    // 1. 创建套接字 (Socket setup, omitted for brevity but required)
    sd_recv = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    sd_send = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));
    
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, IFNAME, IFNAMSIZ - 1);
    ioctl(sd_send, SIOCGIFINDEX, &ifr);
    sll_send.sll_ifindex = ifr.ifr_ifindex;
    
    // 打印路由表信息
    printf("%s Loaded Routing Table (%d entries):\n", ROUTER_NAME, ROUTING_TABLE_SIZE);
    for (int i = 0; i < ROUTING_TABLE_SIZE; i++) {
        printf("  Entry %d: Dst IP: %s -> Next Hop MAC: %02X:%02X:%02X:%02X:%02X:%02X\n", 
            i, routing_table[i].dest_ip, routing_table[i].next_hop_mac[0], routing_table[i].next_hop_mac[1], routing_table[i].next_hop_mac[2], routing_table[i].next_hop_mac[3], routing_table[i].next_hop_mac[4], routing_table[i].next_hop_mac[5]);
    }
    printf("%s is listening on %s...\n", ROUTER_NAME, IFNAME);

    // 主循环: 接收 -> 检查 -> 查表 -> 转发
    while (1) {
        socklen_t sll_len = sizeof(sll_recv);
        int len = recvfrom(sd_recv, buffer, 65536, 0, (struct sockaddr*)&sll_recv, &sll_len);
        if (len <= 0) {
            continue;
        }
        
        struct ethhdr *eth = (struct ethhdr *)buffer;
        
        // --- 过滤 (Filtering) ---
        // L2/L3/L4 过滤逻辑 (MAC, IP, Port)
        if (ntohs(eth->h_proto) != ETH_P_IP || memcmp(eth->h_dest, router_mac, 6) != 0) {
            continue;
        }
        
        struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));

        if (iph->saddr != target_src_ip_addr || iph->protocol != IPPROTO_UDP) {
             continue;
        }
        
        if (len < sizeof(struct ethhdr) + iph->ihl * 4 + sizeof(struct udphdr)) {
            continue;
        }
        struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + iph->ihl * 4);
        if (udph->dest != target_dst_port) {
            continue;
        }
        
        // --- 查表转发 (Routing Table Lookup) ---
        RoutingEntry* route = route_lookup(iph->daddr);
        if (route == NULL) {
            printf("%s: ERROR: Destination IP %s not found in routing table. Datagram Dropped.\n", 
                   ROUTER_NAME, inet_ntoa(*(struct in_addr *)&iph->daddr));
            continue;
        }
        
        // 1. **展示收到数据报信息** print_packet_info(buffer, len, ROUTER_NAME);
        
        // ** (新增) 展示修改前后的数据报关键信息 **
        printf("\n--- %s: Processing Changes BEFORE Forwarding (Next Hop: R2) ---\n", ROUTER_NAME);
        printf("  Current TTL: %d | Checksum: 0x%04X\n", iph->ttl, ntohs(iph->check));
        printf("  MAC Dst: %02X:%02X:%02X:%02X:%02X:%02X (Self)\n", eth->h_dest[0], eth->h_dest[1], eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
        printf("----------------------------------------------------\n");
        
        // 2. **执行 IP 头部修改**
        if (iph->ttl <= 1) {
            printf("WARNING: TTL <= 1, Datagram Dropped.\n");
            continue;
        }
        
        unsigned short old_checksum = iph->check;
        iph->ttl--;       
        iph->check = 0;   
        iph->check = csum((unsigned short *)iph, iph->ihl * 2); 
        
        // 3. **重新构造 MAC 帧头部 (使用查表结果)**
        memcpy(eth->h_source, router_mac, 6);               // 新的源 MAC: R1 的 MAC
        memcpy(eth->h_dest, route->next_hop_mac, 6);        // 新的目的 MAC: R2 的 MAC
        
        printf("\n--- %s: Modifications Completed (Ready to send to R2) ---\n", ROUTER_NAME);
        printf("  TTL Changed: %d -> %d\n", iph->ttl + 1, iph->ttl);
        printf("  Checksum Changed: 0x%04X -> 0x%04X\n", ntohs(old_checksum), ntohs(iph->check));
        printf("  MAC Dst: %02X:%02X:%02X:%02X:%02X:%02X (Next Hop R2)\n", eth->h_dest[0], eth->h_dest[1], eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
        printf("---------------------------------------\n");
        
        // 4. **发送转发后的数据报**
        sll_send.sll_family = AF_PACKET;
        sll_send.sll_halen = ETH_ALEN;
        sll_send.sll_protocol = htons(ETH_P_IP);
        memcpy(sll_send.sll_addr, route->next_hop_mac, 6);

        if (sendto(sd_send, buffer, len, 0, (struct sockaddr*)&sll_send, sizeof(sll_send)) < 0) {
            perror("sendto error");
            continue;
        }
        printf("%s: Forwarding successful to Dst IP %s!\n", ROUTER_NAME, route->dest_ip);
    }

    close(sd_recv);
    close(sd_send);
    return 0;
}