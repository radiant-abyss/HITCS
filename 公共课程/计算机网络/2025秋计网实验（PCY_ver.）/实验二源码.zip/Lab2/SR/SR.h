#pragma once

#include "share.h"
#include <fstream> // 确保 fstream 完整

// SR 窗口日志 (新增)
static void logSRSendWindow(uint8_t base, uint8_t nextSeqNum, int totalFrames, const std::set<uint8_t>& acked_packets, const std::string& logPrefix) {
    if (base >= totalFrames) { log(logPrefix, "SEND WINDOW: Empty (Base=" + std::to_string(base) + ")"); return; }
    std::string status = "SEND WINDOW [" + std::to_string(base) + ", " + std::to_string(nextSeqNum - 1) + "] Status: ";
    std::string packets = "";
    for (uint8_t i = base; i != nextSeqNum; ++i) {
        if (i >= totalFrames) break;
        if (!packets.empty()) packets += ", ";
        packets += std::to_string(i);
        if (acked_packets.count(i)) packets += "(ACKED)";
        else packets += "(PENDING)";
    }
    if (packets.empty()) status += "Empty"; else status += packets;
    log(logPrefix, status);
}

static void logSRRecvWindow(uint8_t recv_base, const std::map<uint8_t, std::vector<char>>& recv_buffer, const std::string& logPrefix) {
    std::string status = "RECV WINDOW [" + std::to_string(recv_base) + ", " + std::to_string(static_cast<uint8_t>(recv_base + WINDOW_SIZE - 1)) + "] Status: ";
    std::string packets = "";
    for (int i = 0; i < WINDOW_SIZE; ++i) {
        uint8_t current = recv_base + i;
        if (!packets.empty()) packets += ", ";
        packets += std::to_string(current);
        if (current == recv_base) packets += "(EXPECTED)";
        else if (recv_buffer.count(current)) packets += "(BUFFERED)";
        else packets += "(EMPTY)";
    }
    log(logPrefix, status + packets);
}

// (srSendAck 辅助函数)
static void srSendAck(SOCKET sock, const sockaddr_in& addr, uint8_t ackNum, const std::string& logPrefix) {
    char ackFrame = static_cast<char>(ackNum);
    log(logPrefix, "SEND ACK " + std::to_string(ackNum));
    sendto(sock, &ackFrame, ACK_FRAME_SIZE, 0, (SOCKADDR*)&addr, sizeof(addr));
}


// SR 接收方逻辑
bool srReceiveFile(SOCKET sock, const sockaddr_in& serverAddr, const std::string& filename, 
                   const std::string& logPrefix, double dataLossRate, double ackLossRate) 
{
    log(logPrefix, "Entering SR receive state for file: " + filename);
    log(logPrefix, "Data Loss (X): " + std::to_string(dataLossRate) + ", ACK Loss (Y): " + std::to_string(ackLossRate));

    std::ofstream outFile(filename, std::ios::binary);
    if (!outFile) { log(logPrefix + "_ERROR", "Failed to create file: " + filename); return false; }

    uint8_t recv_base = 0;
    std::map<uint8_t, std::vector<char>> recv_buffer;
    char recvBuffer[MAX_FRAME_SIZE]; // 1028 字节
    setSocketTimeout(sock, TIMEOUT_MS * 3); 

    logSRRecvWindow(recv_base, recv_buffer, logPrefix); // 初始窗口

    bool finReceived = false;
    
    while (true) {
        int recvLen = recvfrom(sock, recvBuffer, MAX_FRAME_SIZE, 0, NULL, NULL);
        
        std::cout << ("Debug: recvLen = " + std::to_string(recvLen)).c_str() << std::endl ; // Debug line

        if (recvLen == SOCKET_ERROR) { 
            log(logPrefix + "_ERROR", "recvfrom (SR) timed out. Aborting."); break; 
        }
        if (recvLen != MAX_FRAME_SIZE) { continue; }
        
        // (1) 验证校验和
        if (!verifyChecksum(recvBuffer, MAX_FRAME_SIZE)) {
            log(logPrefix, "DISCARD (Checksum Error) Data " + std::to_string(static_cast<uint8_t>(recvBuffer[0])));
            continue; 
        }

        // (2) 模拟数据包丢失 [X]
        if ((static_cast<double>(rand()) / RAND_MAX) < dataLossRate) {
            log(logPrefix, "SIMULATE DATA LOSS of Seq " + std::to_string(static_cast<uint8_t>(recvBuffer[0])));
            continue; 
        }

        // (3) 解析
        uint8_t seqNum = static_cast<uint8_t>(recvBuffer[0]);
        bool isEof = (recvBuffer[MAX_FRAME_SIZE - 1] == FLAG_EOF);
        log(logPrefix, "RECV Frame " + std::to_string(seqNum));

        // (4) SR 接收逻辑
        
        // (Case A: 按序或在缓冲区)
        if (seqNum == recv_base) {
            log(logPrefix, "DELIVER Data " + std::to_string(seqNum));
            // (模拟 ACK 丢失)
            if ((static_cast<double>(rand()) / RAND_MAX) < ackLossRate) log(logPrefix, "SIMULATE ACK LOSS for " + std::to_string(seqNum));
            else srSendAck(sock, serverAddr, seqNum, logPrefix);

            // 交付 base
            if (!isEof) outFile.write(&recvBuffer[FRAME_HEADER_SIZE + FRAME_CHECKSUM_SIZE], DATA_PAYLOAD_SIZE);
            else finReceived = true;
            
            recv_base++; 

            // 检查缓冲区，交付所有连续的包
            while (recv_buffer.count(recv_base)) {
                std::vector<char>& bufferedFrame = recv_buffer[recv_base];
                log(logPrefix, "DELIVER (from buffer) Data " + std::to_string(recv_base));

                bool bufferedEof = (bufferedFrame[MAX_FRAME_SIZE - 1] == FLAG_EOF);
                if (!bufferedEof) outFile.write(&bufferedFrame[FRAME_HEADER_SIZE + FRAME_CHECKSUM_SIZE], DATA_PAYLOAD_SIZE);
                else finReceived = true;
                
                recv_buffer.erase(recv_base);
                recv_base++;
            }
            logSRRecvWindow(recv_base, recv_buffer, logPrefix); // 输出窗口变化
        }
        // (Case B: 乱序但在窗口内)
        else {
            uint8_t distance = (seqNum - recv_base + 256) % 256;
            if (distance < WINDOW_SIZE) { 
                log(logPrefix, "BUFFER (Out of Order) Data " + std::to_string(seqNum));

                if ((static_cast<double>(rand()) / RAND_MAX) < ackLossRate) log(logPrefix, "SIMULATE ACK LOSS for " + std::to_string(seqNum));
                else srSendAck(sock, serverAddr, seqNum, logPrefix); // SR: 确认收到的包
                
                if (recv_buffer.find(seqNum) == recv_buffer.end()) {
                    recv_buffer[seqNum] = std::vector<char>(recvBuffer, recvBuffer + MAX_FRAME_SIZE);
                }
                logSRRecvWindow(recv_base, recv_buffer, logPrefix); // 输出窗口变化 (缓存)
            }
            // (Case C: 窗口外的旧包)
            else if (distance >= (256 - WINDOW_SIZE)) { 
                log(logPrefix, "RECV (Old) Data " + std::to_string(seqNum));
                 if ((static_cast<double>(rand()) / RAND_MAX) < ackLossRate) log(logPrefix, "SIMULATE ACK LOSS for (Old) " + std::to_string(seqNum));
                 else srSendAck(sock, serverAddr, seqNum, logPrefix);
            }
            else { /* 丢弃 */ }
        }
        
        if (finReceived && recv_buffer.empty()) { log(logPrefix, "EOF received and buffer empty. Transfer complete."); break; }
    }
    outFile.close();
    return true;
}

// SR 发送方逻辑

bool srSendFile(SOCKET sock, const sockaddr_in& clientAddr, const std::string& filename, const std::string& logPrefix) {
    log(logPrefix, "Entering SR send state for file: " + filename);
    std::ifstream inFile(filename, std::ios::binary);
    if (!inFile) { log(logPrefix + "_ERROR", "File not found: " + filename); return false; }

    // 1. 加载所有帧 (同 GBN)
    std::vector<std::vector<char>> allFrames;
    uint8_t seq = 0;
    while (true) {
        std::vector<char> frame(MAX_FRAME_SIZE, 0); // 1028 字节
        frame[0] = seq;
        inFile.read(&frame[FRAME_HEADER_SIZE + FRAME_CHECKSUM_SIZE], DATA_PAYLOAD_SIZE);
        int readCount = (int)inFile.gcount();
        if (readCount == 0 && allFrames.empty()) break; 
        
        frame[MAX_FRAME_SIZE - 1] = (inFile.eof() || readCount < DATA_PAYLOAD_SIZE) ? FLAG_EOF : FLAG_DATA;
        setChecksum(frame); // 设置校验和
        allFrames.push_back(frame);
        seq++;
        if (frame[MAX_FRAME_SIZE - 1] == FLAG_EOF) break;
    }
    inFile.close();
    int totalFrames = allFrames.size();
    if (totalFrames == 0) { log(logPrefix, "File is empty."); return true; }
    log(logPrefix, "File divided into " + std::to_string(totalFrames) + " frames.");

    // 2. SR 发送逻辑
    uint8_t base = 0;
    uint8_t nextSeqNum = 0;
    std::map<uint8_t, std::chrono::steady_clock::time_point> packet_timers;
    std::set<uint8_t> acked_packets;
    
    setSocketTimeout(sock, 1); // 1ms 轮询
    char ackBuffer[ACK_FRAME_SIZE];
    sockaddr_in fromAddr;
    int fromAddrLen = sizeof(fromAddr);

    logSRSendWindow(base, nextSeqNum, totalFrames, acked_packets, logPrefix); // 初始窗口

    while (base < totalFrames) {
        // (1) [发送]
        while (nextSeqNum < totalFrames) {
            uint8_t distance = (nextSeqNum - base + 256) % 256;
            if (distance >= WINDOW_SIZE) break; 

            const auto& frameToSend = allFrames[nextSeqNum];
            log(logPrefix, "SEND Data " + std::to_string(nextSeqNum));
            sendto(sock, frameToSend.data(), MAX_FRAME_SIZE, 0, (SOCKADDR*)&clientAddr, sizeof(clientAddr));
            
            packet_timers[nextSeqNum] = std::chrono::steady_clock::now();
            nextSeqNum++;
            logSRSendWindow(base, nextSeqNum, totalFrames, acked_packets, logPrefix); // 输出窗口变化
        }

        
        // (2) [接收 ACK]
        int recvLen = recvfrom(sock, ackBuffer, ACK_FRAME_SIZE, 0, (SOCKADDR*)&fromAddr, &fromAddrLen);
        if (recvLen == ACK_FRAME_SIZE) {
            uint8_t ackNum = static_cast<uint8_t>(ackBuffer[0]);
            log(logPrefix, "RECV ACK " + std::to_string(ackNum));
            
            uint8_t distance = (ackNum - base + 256) % 256;
            if (distance < WINDOW_SIZE) { // 必须在窗口内
                if (acked_packets.find(ackNum) == acked_packets.end()) {
                     acked_packets.insert(ackNum);
                     packet_timers.erase(ackNum); // 停止计时
                     log(logPrefix, "Marked Data " + std::to_string(ackNum) + " as ACKed.");
                }

                if (ackNum == base) {
                    while (acked_packets.count(base) && base < totalFrames) {
                        acked_packets.erase(base);
                        base++;
                    }
                    log(logPrefix, "SEND WINDOW base slides to " + std::to_string(base));
                }
                logSRSendWindow(base, nextSeqNum, totalFrames, acked_packets, logPrefix); // 输出窗口变化
            }
        } else { /* 1ms 轮询超时 */ }


        // (3) [检查超时]
        auto now = std::chrono::steady_clock::now();
        for (auto it = packet_timers.begin(); it != packet_timers.end(); ) {
            uint8_t seq = it->first;
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(now - it->second).count();

            if (duration > TIMEOUT_MS) {
                log(logPrefix, "TIMEOUT for Data " + std::to_string(seq) + "! Resending.");
                const auto& frameToResend = allFrames[seq];
                sendto(sock, frameToResend.data(), MAX_FRAME_SIZE, 0, (SOCKADDR*)&clientAddr, sizeof(clientAddr));
                packet_timers[seq] = now; // 重启定时器
                
                logSRSendWindow(base, nextSeqNum, totalFrames, acked_packets, logPrefix); // 输出窗口 (重传)
                ++it;
            } else {
                ++it;
            }
        }
        Sleep(1);
    }

    log(logPrefix, "SR send complete.");
    setSocketTimeout(sock, 0); // 恢复阻塞
    return true;
}