#pragma once

// 禁用WINSOCK API的弃用警告
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <WinSock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <string>
#include <vector>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <mutex>
#include <ctime>
#include <cstdlib>
#include <fstream> // 用于文件 I/O
#include <map>     // 用于 SR 缓冲区
#include <set>     // 用于 SR ACK 集合
#include <cstdint> // 用于 uint8_t, uint16_t, uint32_t
#include <cstring> // 用于 memcpy 和 memset
// 链接Winsock库
#pragma comment(lib, "ws2_32.lib")

// --- 协议配置 ---
#define SERVER_PORT 8888       
#define TIMEOUT_MS 2000        // GBN/SR 超时时间
#define WINDOW_SIZE 15         // 窗口大小 (W=15, L=8, GBN: 15+1 <= 256; SR: 15 <= 128)

// --- 帧结构 (带校验和) ---
#define FRAME_HEADER_SIZE 1    // 1字节 序列号 (Seq)
#define FRAME_CHECKSUM_SIZE 2  // 2字节 校验和 (Checksum)
#define DATA_PAYLOAD_SIZE 1024 // 1024字节 数据
#define FRAME_TRAILER_SIZE 1   // 1字节 结束标记 (EOF Flag)

// (1 + 2 + 1024 + 1 = 1028 字节)
#define MAX_FRAME_SIZE (FRAME_HEADER_SIZE + FRAME_CHECKSUM_SIZE + DATA_PAYLOAD_SIZE + FRAME_TRAILER_SIZE) 

#define ACK_FRAME_SIZE 1       // 1字节 ACK
#define FLAG_DATA 1
#define FLAG_EOF 0

// --- 控制消息类型 ---
#define MSG_OK "OK"
#define MSG_ERR "Error"
#define MSG_GOODBYE "Good bye!"

// --- 日志记录辅助函数 ---
static std::mutex logMutex; 
static std::string getCurrentTime() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
    std::tm bt;
    localtime_s(&bt, &in_time_t);
    std::ostringstream ss;
    ss << std::put_time(&bt, "%H:%M:%S");
    ss << '.' << std::setfill('0') << std::setw(3) << ms.count();
    return ss.str();
}


static void log(const std::string& prefix, const std::string& message) {
    std::lock_guard<std::mutex> lock(logMutex);
    std::cout << "[" << getCurrentTime() << "] " << prefix << ": " << message << std::endl;
}

static void setSocketTimeout(SOCKET sock, DWORD timeout_ms) {
    if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout_ms, sizeof(timeout_ms)) == SOCKET_ERROR) {
        log("NET_ERROR", "setsockopt (SO_RCVTIMEO) failed: " + std::to_string(WSAGetLastError()));
    }
}

// 位于 common.h

/**
 * @brief 修正版：计算 16 位互联网校验和 (字节序安全)
 */
static uint16_t calculateChecksum(const char* data, int len) {
    uint32_t sum = 0;
    const uint16_t* ptr = reinterpret_cast<const uint16_t*>(data);

    // 每次加两个字节
    while (len > 1) {
        sum += *ptr++;
        if (sum & 0xFFFF0000)
            sum = (sum & 0xFFFF) + (sum >> 16);
        len -= 2;
    }

    // 如果是奇数个字节，补0
    if (len > 0) {
        uint16_t last = static_cast<unsigned char>(*reinterpret_cast<const unsigned char*>(ptr));
        sum += last;
        if (sum & 0xFFFF0000)
            sum = (sum & 0xFFFF) + (sum >> 16);
    }

    // 取反码
    return static_cast<uint16_t>(~sum);
}

/**
 * @brief 修正版：验证校验和
 */
static bool verifyChecksum(const char* buffer, int len) {
    if (len < 8) return false; // UDP头部最少8字节

    // 取出原始校验和字段（位于偏移6字节处）
    uint16_t received_checksum;
    std::memcpy(&received_checksum, buffer + 6, sizeof(uint16_t));

    // 复制数据报并将校验和字段清零
    char* temp = new char[len];
    std::memcpy(temp, buffer, len);
    std::memset(temp + 6, 0, 2);  // UDP头部checksum字段清0

    // 计算新的校验和
    uint16_t computed = calculateChecksum(temp, len);
    delete[] temp;

    // 若相等则正确
    return (computed == received_checksum);
}

/**
 * @brief 辅助函数：在数据帧中设置校验和
 */
static void setChecksum(std::vector<char>& frame) {
    frame[FRAME_HEADER_SIZE] = 0;
    frame[FRAME_HEADER_SIZE + 1] = 0;
    uint16_t checksum = calculateChecksum(frame.data(), MAX_FRAME_SIZE);
    frame[FRAME_HEADER_SIZE] = (checksum >> 8) & 0xFF;   
    frame[FRAME_HEADER_SIZE + 1] = checksum & 0xFF; 
}