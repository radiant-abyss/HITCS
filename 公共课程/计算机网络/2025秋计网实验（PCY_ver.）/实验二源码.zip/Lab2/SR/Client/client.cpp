#include "../share.h"
#include "../SR.h" // 包含 SR 逻辑
#include <fstream> // 确保 fstream 完整

// 客户端的丢包率 (全局状态)
double dataLossRate = 0.2;
double ackLossRate = 0.2;

// 辅助函数：解析命令
void parseCommand(const std::string& raw, std::string& cmd, std::string& arg1, std::string& arg2) {
    std::stringstream ss(raw);
    ss >> cmd >> arg1 >> arg2;
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) { log("CLIENT_ERROR", "WSAStartup failed."); return 1; }
    SOCKET clientSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    setSocketTimeout(clientSocket, TIMEOUT_MS); 

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr);

    srand(static_cast<unsigned int>(time(NULL)));

    std::string input;
    char responseBuffer[1024];

    log("CLIENT", "Default loss rates: Data (X) = " + std::to_string(dataLossRate) + 
                  ", ACK (Y) = " + std::to_string(ackLossRate));
    log("CLIENT", "Use '-testgbn [X] [Y]' to set loss rates (e.g., -testgbn 0.1 0.3)");

    while (true) {
        std::cout << "\n> ";
        std::getline(std::cin, input);
        if (input.empty()) continue;

        std::string cmd, arg1, arg2;
        parseCommand(input, cmd, arg1, arg2);

        // (1) 本地命令 -testgbn [X] [Y]
        if (cmd == "-setloss")
        {
            try {
                dataLossRate = arg1.empty() ? 0.2 : std::stod(arg1);
                ackLossRate = arg2.empty() ? 0.2 : std::stod(arg2);
                dataLossRate = std::max(0.0, std::min(1.0, dataLossRate));
                ackLossRate = std::max(0.0, std::min(1.0, ackLossRate));

                log("CLIENT", "Loss rates updated. Data (X) = " + std::to_string(dataLossRate) + 
                              ", ACK (Y) = " + std::to_string(ackLossRate));
            } catch (const std::exception& e) {
                log("CLIENT_ERROR", "Invalid format for -testgbn. Usage: -testgbn [X] [Y]");
            }
            continue;
        }

        // (2) 检查本地文件 (仅上传时)
        if (cmd == "upload" && !arg1.empty()) {
            std::ifstream testFile(arg1);
            if (!testFile) {
                log("CLIENT_ERROR", "Local file not found: " + arg1);
                continue;
            }
            testFile.close();
        }

        // (3) 发送命令到服务器
        sendto(clientSocket, input.c_str(), input.length(), 0, (SOCKADDR*)&serverAddr, sizeof(serverAddr));

        if (cmd == "-quit") { log("CLIENT", "Quitting..."); }

        // (4) 等待服务器回复
        int recvLen = recvfrom(clientSocket, responseBuffer, sizeof(responseBuffer) - 1, 0, NULL, NULL);

        if (recvLen == SOCKET_ERROR) { log("CLIENT_ERROR", "Server timed out."); continue; }
        
        responseBuffer[recvLen] = '\0';
        std::string response(responseBuffer);
        log("SERVER_REPLY", response);

        if (cmd == "-quit" && response == MSG_GOODBYE) { break; }

        // (5) 如果回复 OK，启动 SR
        if (response == MSG_OK) {
            if (cmd == "upload" && !arg1.empty()) {
                // 调用 SR 发送
                srSendFile(clientSocket, serverAddr, arg1, "CLIENT_SEND"); 
            }
            else if (cmd == "download" && !arg1.empty()) {
                std::string save_filename = "client_sr_" + arg1; // <-- 文件名更新
                // 调用 SR 接收
                srReceiveFile(clientSocket, serverAddr, save_filename, "CLIENT_RECV", dataLossRate, ackLossRate);
            }
        }
    }

    closesocket(clientSocket);
    WSACleanup();
    return 0;
}