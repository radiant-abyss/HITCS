#include "../common.h"
#include "../gbn_logic.h" // 包含 GBN 逻辑

// 客户端的丢包率 
double dataLossRate = 0.2;
double ackLossRate = 0.2;

// 辅助函数：解析命令
void parseCommand(const std::string& raw, std::string& cmd, std::string& filename) {
    std::stringstream ss(raw);
    ss >> cmd;
    ss >> filename;
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        log("CLIENT_ERROR", "WSAStartup failed."); return 1;
    }
    SOCKET clientSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    setSocketTimeout(clientSocket, TIMEOUT_MS); // 默认超时

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr);

    srand(static_cast<unsigned int>(time(NULL)));

    std::string input;
    char responseBuffer[1024];

    while (true) {
        std::cout << "\n> ";
        std::getline(std::cin, input);
        if (input.empty()) continue;

        // 解析命令
        std::string cmd, arg1, arg2;
        std::stringstream ss(input);
        ss >> cmd >> arg1 >> arg2;

        // (1) 特殊本地命令 setloss
        if (cmd == "-setloss") {
            dataLossRate = arg1.empty() ? 0.2 : std::stod(arg1);
            ackLossRate = arg2.empty() ? 0.2 : std::stod(arg2);
            log("CLIENT", "Loss rates set. Data (X) = " + std::to_string(dataLossRate) + 
                          ", ACK (Y) = " + std::to_string(ackLossRate));
            continue;
        }

        // (2) 检查本地文件 (仅上传时)
        if (cmd == "upload" && !arg1.empty()) {
            std::ifstream testFile(arg1);
            if (!testFile) {
                log("CLIENT_ERROR", "Local file not found: " + arg1);
                continue;
            }
            testFile.close();
        }

        // (3) 发送命令到服务器
        sendto(clientSocket, input.c_str(), input.length(), 0, (SOCKADDR*)&serverAddr, sizeof(serverAddr));

        if (cmd == "-quit") {
            log("CLIENT", "Quitting...");
        }

        // (4) 等待服务器回复
        sockaddr_in fromAddr;
        int fromAddrLen = sizeof(fromAddr);
        int recvLen = recvfrom(clientSocket, responseBuffer, sizeof(responseBuffer) - 1, 0, (SOCKADDR*)&fromAddr, &fromAddrLen);

        if (recvLen == SOCKET_ERROR) {
            log("CLIENT_ERROR", "Server timed out.");
            continue;
        }
        
        responseBuffer[recvLen] = '\0';
        std::string response(responseBuffer);
        log("SERVER_REPLY", response);

        if (cmd == "-quit" && response == MSG_GOODBYE) {
            break; // 退出
        }

        // (5) 如果回复 OK，启动 GBN
        if (response == MSG_OK) {
            if (cmd == "upload" && !arg1.empty()) {
                // 启动 GBN 发送
                gbnSendFile(clientSocket, serverAddr, arg1, "CLIENT_SEND");
            }
            else if (cmd == "download" && !arg1.empty()) {
                // 启动 GBN 接收 (带丢包模拟)
                std::string save_filename = "client_" + arg1;
                gbnReceiveFile(clientSocket, serverAddr, save_filename, "CLIENT_RECV", dataLossRate, ackLossRate);
            }
        }
    }

    closesocket(clientSocket);
    WSACleanup();
    return 0;
}