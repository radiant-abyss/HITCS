#pragma once

#include "common.h"
#include <fstream> // 确保 fstream 完整


// GBN 接收方逻辑
bool gbnReceiveFile(SOCKET sock, const sockaddr_in& serverAddr, const std::string& filename, 
                    const std::string& logPrefix, double dataLossRate, double ackLossRate) 
{
    //  (日志, 打开文件等) 
    std::ofstream outFile(filename, std::ios::binary);
    if (!outFile) {  return false; } // 文件打开失败

    char recvBuffer[MAX_FRAME_SIZE]; // 1028 字节
    uint8_t expectedSeqNum = 0;
    setSocketTimeout(sock, TIMEOUT_MS * 2); 

    while (true) {
        int recvLen = recvfrom(sock, recvBuffer, MAX_FRAME_SIZE, 0, NULL, NULL);

        if (recvLen == SOCKET_ERROR) { break; }

        // (1) 检查长度 (现在必须是 1028)
        if (recvLen != MAX_FRAME_SIZE) {
            log(logPrefix + "_WARN", "Received incomplete frame, size: " + std::to_string(recvLen));
            continue;
        }
        
        // (2) 验证校验和
        // (必须在模拟丢包之前，因为损坏的包也应该被丢弃)
        if (!verifyChecksum(recvBuffer, MAX_FRAME_SIZE)) {
            log(logPrefix, "DISCARD (Checksum Error) Data " + std::to_string(static_cast<uint8_t>(recvBuffer[0])));
            // 丢弃损坏的帧, 不发送ACK
            continue; 
        }

        // (3) 模拟数据包丢失 [X]
        if ((static_cast<double>(rand()) / RAND_MAX) < dataLossRate) {
            log(logPrefix, "SIMULATE DATA LOSS of Seq " + std::to_string(static_cast<uint8_t>(recvBuffer[0])));
            continue; 
        }

        // (4) 解析 (校验和通过后)
        uint8_t seqNum = static_cast<uint8_t>(recvBuffer[0]);
        bool isEof = (recvBuffer[MAX_FRAME_SIZE - 1] == FLAG_EOF);
        log(logPrefix, "RECV Data " + std::to_string(seqNum));

        
        if (seqNum == expectedSeqNum) {
            log(logPrefix, "ACCEPT Data " + std::to_string(seqNum));
            
            if (!isEof) {
                // (数据偏移量已更改，跳过 Seq(1) 和 Checksum(2))
                outFile.write(&recvBuffer[FRAME_HEADER_SIZE + FRAME_CHECKSUM_SIZE], DATA_PAYLOAD_SIZE);
            }

            // (5) 模拟 ACK 丢失 [Y]
            if ((static_cast<double>(rand()) / RAND_MAX) < ackLossRate) {
                log(logPrefix, "SIMULATE ACK LOSS for " + std::to_string(expectedSeqNum));
            } else {
                char ackFrame = static_cast<char>(expectedSeqNum);
                log(logPrefix, "SEND ACK " + std::to_string(expectedSeqNum));
                sendto(sock, &ackFrame, ACK_FRAME_SIZE, 0, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
            }
            
            expectedSeqNum++; 

            if (isEof) {  break; } // 结束接收


        } else {
            // (6) 失序包 (GBN)
            log(logPrefix, "DISCARD (Out of Order) Data " + std::to_string(seqNum) + ". Expected: " + std::to_string(expectedSeqNum));
            if (expectedSeqNum > 0) {
                 // (模拟 ACK 丢失 [Y])
                if ((static_cast<double>(rand()) / RAND_MAX) < ackLossRate) {
                    log(logPrefix, "SIMULATE ACK LOSS for (Dup) " + std::to_string(expectedSeqNum - 1));
                } else {
                    char ackFrame = static_cast<char>(expectedSeqNum - 1);
                    log(logPrefix, "RESEND ACK " + std::to_string(expectedSeqNum - 1));
                    sendto(sock, &ackFrame, ACK_FRAME_SIZE, 0, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
                }
            }
        }
    }
    outFile.close();
    return true;
}


// GBN 发送方逻辑
bool gbnSendFile(SOCKET sock, const sockaddr_in& clientAddr, const std::string& filename, const std::string& logPrefix) {
    //  (打开文件) 
    std::ifstream inFile(filename, std::ios::binary);
    if (!inFile) {  return false; }

    // 1. 加载所有帧
    std::vector<std::vector<char>> allFrames;
    uint8_t seq = 0;
    while (true) {
        std::vector<char> frame(MAX_FRAME_SIZE, 0); // 1028 字节

        // 1. Seq
        frame[0] = seq;
        // 2. 校验和 (暂时留空 0)
        // 3. Data (注意偏移量)
        inFile.read(&frame[FRAME_HEADER_SIZE + FRAME_CHECKSUM_SIZE], DATA_PAYLOAD_SIZE);
        int readCount = (int)inFile.gcount();
        if (readCount == 0 && allFrames.empty()) break; 
        
        // 4. Flag
        frame[MAX_FRAME_SIZE - 1] = (inFile.eof() || readCount < DATA_PAYLOAD_SIZE) ? FLAG_EOF : FLAG_DATA;
        
        // 5. [新增] 计算并设置校验和
        setChecksum(frame); // 调用 common.h 中的辅助函数

        allFrames.push_back(frame);
        seq++;
        if (frame[MAX_FRAME_SIZE - 1] == FLAG_EOF) break;
    }
    inFile.close();
    
    if (allFrames.empty()) {
        log(logPrefix, "No data to send.");
        return true; 
    }
    
    // 2. GBN 发送逻辑
    //  (base, nextSeqNum, 1ms 轮询, timer) 
    // (GBN 发送循环)
    uint8_t base = 0;
    uint8_t nextSeqNum = 0;
    setSocketTimeout(sock, 1); // 1ms 轮询
    auto gbn_timer_start = std::chrono::steady_clock::now();
    bool is_timer_running = false;
    char ackBuffer[ACK_FRAME_SIZE];
    sockaddr_in fromAddr;
    int fromAddrLen = sizeof(fromAddr);

    while (base < allFrames.size()) {
        // (1) 发送 
        while (nextSeqNum < allFrames.size()) {
            uint8_t distance = (nextSeqNum - base + 256) % 256;
            if (distance >= WINDOW_SIZE) break; 

            const auto& frameToSend = allFrames[nextSeqNum];
            log(logPrefix, "SEND Data " + std::to_string(nextSeqNum));
            sendto(sock, frameToSend.data(), MAX_FRAME_SIZE, 0, (SOCKADDR*)&clientAddr, sizeof(clientAddr));
            
            if (base == nextSeqNum) {
                gbn_timer_start = std::chrono::steady_clock::now();
                is_timer_running = true;
                log(logPrefix, "TIMER START for base " + std::to_string(base));
            }
            nextSeqNum++;
        }

        // (2) 接收 ACK
        int recvLen = recvfrom(sock, ackBuffer, ACK_FRAME_SIZE, 0, (SOCKADDR*)&fromAddr, &fromAddrLen);
        if (recvLen == ACK_FRAME_SIZE) {
            uint8_t ackNum = static_cast<uint8_t>(ackBuffer[0]);
            log(logPrefix, "RECV ACK " + std::to_string(ackNum));
            
            uint8_t distance = (ackNum - base + 256) % 256;
            if (distance < WINDOW_SIZE) {
                base = ackNum + 1; 
                log(logPrefix, "Window base moved to " + std::to_string(base));
                if (base == nextSeqNum) {
                    is_timer_running = false;
                    log(logPrefix, "TIMER STOP (window empty)");
                } else {
                    gbn_timer_start = std::chrono::steady_clock::now();
                    log(logPrefix, "TIMER RESTART for new base " + std::to_string(base));
                }
            }
        } else { /* 1ms 轮询超时，不做处理，等待下一轮 */ }

        // (3) 检查超时 
        if (is_timer_running) {
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - gbn_timer_start).count();
            if (duration > TIMEOUT_MS) {
                log(logPrefix, "TIMEOUT! Retransmitting window from " + std::to_string(base));
                for (uint8_t i = base; i != nextSeqNum; ++i) {
                    const auto& frameToResend = allFrames[i];
                    log(logPrefix, "RESEND Data " + std::to_string(i));
                    sendto(sock, frameToResend.data(), MAX_FRAME_SIZE, 0, (SOCKADDR*)&clientAddr, sizeof(clientAddr));
                }
                gbn_timer_start = std::chrono::steady_clock::now();
                log(logPrefix, "TIMER RESTART after retransmission");
            }
        }
        Sleep(1);
    }
    //  (结束) 

    log(logPrefix, "GBN send complete.");
    setSocketTimeout(sock, 0); // 恢复阻塞
    return true;
}