#include "../common.h"
#include "../gbn_logic.h" // 包含 GBN 逻辑

// 辅助函数：解析命令
void parseCommand(const std::string& raw, std::string& cmd, std::string& filename) {
    std::stringstream ss(raw);
    ss >> cmd;
    ss >> filename;
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        log("SERVER_ERROR", "WSAStartup failed.");
        return 1;
    }
    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    setSocketTimeout(serverSocket, 0); // 默认阻塞等待命令

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(SERVER_PORT);
    if (bind(serverSocket, (SOCKADDR*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        log("SERVER_ERROR", "Bind failed.");
        closesocket(serverSocket); WSACleanup(); return 1;
    }
    log("SERVER", "GBN Server running, waiting for commands on port " + std::to_string(SERVER_PORT));

    char cmdBuffer[1024];
    sockaddr_in clientAddr;
    int clientAddrLen = sizeof(clientAddr);

    while (true) {
        // 1. 阻塞等待命令
        log("SERVER", "Waiting for new command...");
        int recvLen = recvfrom(serverSocket, cmdBuffer, sizeof(cmdBuffer) - 1, 0, (SOCKADDR*)&clientAddr, &clientAddrLen);
        if (recvLen <= 0) continue;
        cmdBuffer[recvLen] = '\0';
        
        std::string rawCmd(cmdBuffer);
        std::string cmd, filename;
        parseCommand(rawCmd, cmd, filename);
        log("SERVER", "Received command: '" + cmd + "' Filename: '" + filename + "'");

        std::string response;

        if (cmd == "-time") {
            response = "Server time: " + getCurrentTime();
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
        }
        else if (cmd == "-quit") {
            response = MSG_GOODBYE;
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
        }
        else if (cmd == "upload" && !filename.empty()) {
            // 客户端请求上传
            std::string save_filename = "server_" + filename;
            response = MSG_OK;
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
            
            // 进入 GBN 接收逻辑 (服务器接收时不模拟丢包)
            gbnReceiveFile(serverSocket, clientAddr, save_filename, "SERVER_RECV", 0.0, 0.0);
        }
        else if (cmd == "download" && !filename.empty()) {
            // 客户端请求下载
            std::ifstream testFile(filename);
            if (!testFile) {
                response = std::string(MSG_ERR) + ": File not found";
                sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
            } else {
                testFile.close();
                response = MSG_OK;
                sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
                
                // 进入 GBN 发送逻辑
                gbnSendFile(serverSocket, clientAddr, filename, "SERVER_SEND");
            }
        }
        else {
            response = std::string(MSG_ERR) + ": Unknown command";
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
        }
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}