#include "Share.h"
#include <map>

// 存储所有准备好的数据帧 (Seq + Data + EOF)
std::vector<std::vector<char>> allFrames;

// 准备要发送的所有数据帧 

void prepareFrames() {
    allFrames.clear();
    log("SERVER_GBN", "Preparing " + std::to_string(TOTAL_PACKETS) + " frames...");

    for (int i = 0; i < TOTAL_PACKETS; ++i) {
        // 创建一个 1026 字节的缓冲区
        std::vector<char> frame(MAX_FRAME_SIZE, 0); // 初始化为0

        // 序列号 (1字节)
        frame[0] = static_cast<uint8_t>(i);

        // 数据 (<= 1024 字节)
        std::string data = "This is packet " + std::to_string(i);
        memcpy(&frame[FRAME_HEADER_SIZE], data.c_str(), data.length());

        // 最后一个字节 (EOF Flag)
        // 1 表示数据, 0 表示结束
        frame[MAX_FRAME_SIZE - 1] = (i == TOTAL_PACKETS - 1) ? FLAG_EOF : FLAG_DATA;

        allFrames.push_back(frame);
    }
}

// GBN 发送逻辑
// 使用非阻塞流水线实现

void startGbnSend(SOCKET serverSocket, const sockaddr_in& clientAddr) {
    log("SERVER", "Entering GBN transfer state...");
    prepareFrames(); // 准备所有数据帧

    // GBN 状态变量 (使用1字节序列号)
    uint8_t base = 0;
    uint8_t nextSeqNum = 0;
    
    // 切换到非阻塞 (1ms轮询) 模式
    setSocketTimeout(serverSocket, 1); 

    // GBN 唯一计时器
    auto gbn_timer_start = std::chrono::steady_clock::now();
    bool is_timer_running = false;

    // ACK 缓冲区
    char ackBuffer[ACK_FRAME_SIZE];
    sockaddr_in fromAddr;
    int fromAddrLen = sizeof(fromAddr);

    // 只要 base 还没追上所有包的总数，就继续循环
    while (base < TOTAL_PACKETS) {
        
        // (1) [发送] 检查窗口是否已满，如果不满，立即发送新包
        // (W=15)
        // (由于 TOTAL_PACKETS < 255, 我们不需要处理序列号回绕)
        while (nextSeqNum < base + WINDOW_SIZE && nextSeqNum < TOTAL_PACKETS) {
            const auto& frameToSend = allFrames[nextSeqNum];
            
            log("SERVER_GBN", "SEND Data " + std::to_string(nextSeqNum));
            sendto(serverSocket, frameToSend.data(), MAX_FRAME_SIZE, 0, (SOCKADDR*)&clientAddr, sizeof(clientAddr));
            
            if (base == nextSeqNum) {
                gbn_timer_start = std::chrono::steady_clock::now();
                is_timer_running = true;
                log("SERVER_GBN", "TIMER START for base " + std::to_string(base));
            }
            nextSeqNum++;
        }

        // (2) [接收] 非阻塞地检查是否有 1字节的ACK 到达
        int recvLen = recvfrom(serverSocket, ackBuffer, ACK_FRAME_SIZE, 0, (SOCKADDR*)&fromAddr, &fromAddrLen);

        if (recvLen == ACK_FRAME_SIZE) {
            // (1字节ACK)
            uint8_t ackNum = static_cast<uint8_t>(ackBuffer[0]);
            log("SERVER_GBN", "RECV ACK " + std::to_string(ackNum));
            
            // 累积确认: 如果收到的 ACK >= base，就移动窗口
            if (ackNum >= base) {
                base = ackNum + 1;
                log("SERVER_GBN", "Window base moved to " + std::to_string(base));
                
                if (base == nextSeqNum) {
                    is_timer_running = false;
                    log("SERVER_GBN", "TIMER STOP (window empty)");
                } else {
                    gbn_timer_start = std::chrono::steady_clock::now();
                    log("SERVER_GBN", "TIMER RESTART for new base " + std::to_string(base));
                }
            }
        } else if (recvLen > 0) {
            log("SERVER_WARN", "Received an invalid ACK frame size: " + std::to_string(recvLen));
            // 可能是客户端发来的命令，丢弃
        } else {
            int error = WSAGetLastError();
            if (error != WSAETIMEDOUT && error != 0) {
                log("SERVER_ERROR", "recvfrom poll failed: " + std::to_string(error));
            }
        }

        // (3) [计时] 检查 GBN 的唯一计时器是否超时
        if (is_timer_running) {
            auto now = std::chrono::steady_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(now - gbn_timer_start).count();

            if (duration > TIMEOUT_MS) {
                log("SERVER_GBN", "TIMEOUT! Retransmitting window from " + std::to_string(base));
                
                for (uint8_t i = base; i < nextSeqNum; ++i) {
                    const auto& frameToResend = allFrames[i];
                    log("SERVER_GBN", "RESEND Data " + std::to_string(i));
                    sendto(serverSocket, frameToResend.data(), MAX_FRAME_SIZE, 0, (SOCKADDR*)&clientAddr, sizeof(clientAddr));
                }
                
                // 重启计时器
                gbn_timer_start = std::chrono::steady_clock::now();
                log("SERVER_GBN", "TIMER RESTART after retransmission");
            }
        }
        
        Sleep(1); // 避免CPU 100% 占用
    }

    log("SERVER", "GBN transfer complete. Returning to command mode.");
    // 切换回阻塞模式，等待新命令
    setSocketTimeout(serverSocket, 0);
}



// 主函数：命令解析器
int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        log("SERVER_ERROR", "WSAStartup failed.");
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (serverSocket == INVALID_SOCKET) {
        log("SERVER_ERROR", "Socket creation failed.");
        WSACleanup();
        return 1;
    }

    // 默认使用阻塞模式 (timeout=0) 来等待命令
    setSocketTimeout(serverSocket, 0);

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(SERVER_PORT);

    if (bind(serverSocket, (SOCKADDR*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        log("SERVER_ERROR", "Bind failed.");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    log("SERVER", "Server is running, waiting for commands on port " + std::to_string(SERVER_PORT));

    char cmdBuffer[1024];
    sockaddr_in clientAddr;
    int clientAddrLen = sizeof(clientAddr);

    // (命令解析循环)
    while (true) {
        int recvLen = recvfrom(serverSocket, cmdBuffer, sizeof(cmdBuffer) - 1, 0, (SOCKADDR*)&clientAddr, &clientAddrLen);
        if (recvLen <= 0) {
            log("SERVER_ERROR", "recvfrom (command) failed.");
            continue;
        }

        cmdBuffer[recvLen] = '\0'; // 确保字符串结束
        std::string command(cmdBuffer);
        log("SERVER", "Received command: '" + command + "'");

        std::string response;

        if (command == "-time") {
            response = "Server time: " + getCurrentTime();
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
        }
        else if (command == "-quit") {
            response = "Good bye!";
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
        }
        else if (command.rfind("-testgbn", 0) == 0) {
            response = "ACK: Starting GBN test.";
            // 回复确认启动 GBN
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
            // 进入GBN发送状态
            startGbnSend(serverSocket, clientAddr);
        }
        else {
            // Echo
            response = "ECHO: " + command;
            sendto(serverSocket, response.c_str(), response.length(), 0, (SOCKADDR*)&clientAddr, clientAddrLen);
        }
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}