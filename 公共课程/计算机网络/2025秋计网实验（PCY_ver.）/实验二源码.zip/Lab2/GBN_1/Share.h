#pragma once

// 禁用WINSOCK API的弃用警告
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <WinSock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <string>
#include <vector>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <mutex>
#include <ctime>
#include <cstdlib>

// 链接Winsock库
#pragma comment(lib, "ws2_32.lib")

// 协议配置 
#define SERVER_PORT 8888       // 服务器端口
#define TIMEOUT_MS 2000        // GBN超时时间 (2000ms)

// (L=8 (1字节Seq), W+1 <= 2^L -> W+1 <= 256 -> W <= 255)
#define WINDOW_SIZE 15         // GBN窗口大小 (W)

// (Data <= 1024)
#define DATA_PAYLOAD_SIZE 1024 // 数据帧中数据 payload 的最大大小

// (Seq(1) + Data(1024) + EOF(1))
#define FRAME_HEADER_SIZE 1    // 1字节 序列号 (Seq)
#define FRAME_TRAILER_SIZE 1   // 1字节 结束标记 (EOF Flag)
#define MAX_FRAME_SIZE (FRAME_HEADER_SIZE + DATA_PAYLOAD_SIZE + FRAME_TRAILER_SIZE) // 1026 字节

// (ACK 1字节)
#define ACK_FRAME_SIZE 1       // 1字节 ACK

// (EOF Flag. 1=Data, 0=End)
#define FLAG_DATA 1
#define FLAG_EOF 0

// 模拟发送的数据包总数 (用于 -testgbn)
#define TOTAL_PACKETS 30

// 日志记录辅助函数 (不变)
static std::mutex logMutex; 

// 获取当前时间字符串 H:M:S.ms
static std::string getCurrentTime() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
    std::tm bt;
    localtime_s(&bt, &in_time_t); // Windows-specific-safe afunction
    std::ostringstream ss;
    ss << std::put_time(&bt, "%H:%M:%S");
    ss << '.' << std::setfill('0') << std::setw(3) << ms.count();
    return ss.str();
}

// 打印日志
static void log(const std::string& prefix, const std::string& message) {
    std::lock_guard<std::mutex> lock(logMutex);
    std::cout << "[" << getCurrentTime() << "] " << prefix << ": " << message << std::endl;
}

// 辅助函数：设置socket超时
static void setSocketTimeout(SOCKET sock, DWORD timeout_ms) {
    if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout_ms, sizeof(timeout_ms)) == SOCKET_ERROR) {
        log("NET_ERROR", "setsockopt (SO_RCVTIMEO) failed: " + std::to_string(WSAGetLastError()));
    }
}