#include "Share.h"

// 客户端的丢包率
double dataLossRate = 0.2;
double ackLossRate = 0.2;


// 发送 1 字节的 ACK，并模拟 ACK 丢失
void sendAck(SOCKET clientSocket, const sockaddr_in& serverAddr, uint8_t ackNum) {
    // (模拟 ACK 丢失 [Y])
    if ((static_cast<double>(rand()) / RAND_MAX) < ackLossRate) {
        log("CLIENT_GBN", "SIMULATE ACK LOSS for " + std::to_string(ackNum));
        return; // ACK 丢失
    }
    
    // ( ACK 帧为 1 字节)
    char ackFrame = static_cast<char>(ackNum);
    
    log("CLIENT_GBN", "SEND ACK " + std::to_string(ackNum));
    if (sendto(clientSocket, &ackFrame, ACK_FRAME_SIZE, 0, (SOCKADDR*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        log("CLIENT_ERROR", "sendto (ACK) failed: " + std::to_string(WSAGetLastError()));
    }
}


// GBN 接收逻辑

void startGbnReceive(SOCKET clientSocket, const sockaddr_in& serverAddr) {
    log("CLIENT", "Entering GBN receive state...");
    log("CLIENT", "Data Loss Rate (X): " + std::to_string(dataLossRate) + ", ACK Loss Rate (Y): " + std::to_string(ackLossRate));

    // 接收缓冲区
    char recvBuffer[MAX_FRAME_SIZE];
    uint8_t expectedSeqNum = 0;
    
    // GBN 接收需要超时，以防服务器崩溃
    setSocketTimeout(clientSocket, TIMEOUT_MS * 2);

    while (true) {
        sockaddr_in fromAddr;
        int fromAddrLen = sizeof(fromAddr);
        int recvLen = recvfrom(clientSocket, recvBuffer, MAX_FRAME_SIZE, 0, (SOCKADDR*)&fromAddr, &fromAddrLen);

        if (recvLen == SOCKET_ERROR) {
            log("CLIENT_ERROR", "recvfrom (GBN) timed out. Exiting GBN mode.");
            break;
        }

        if (recvLen != MAX_FRAME_SIZE) {
            log("CLIENT_WARN", "Received incomplete frame, size: " + std::to_string(recvLen) + ". Discarding.");
            continue;
        }

        // (模拟数据包丢失 [X])
        if ((static_cast<double>(rand()) / RAND_MAX) < dataLossRate) {
            log("CLIENT_GBN", "SIMULATE DATA LOSS of Seq " + std::to_string(static_cast<uint8_t>(recvBuffer[0])));
            continue; // 丢弃该包，不发送ACK
        }

        // 解析数据帧
        uint8_t seqNum = static_cast<uint8_t>(recvBuffer[0]);
        bool isEof = (recvBuffer[MAX_FRAME_SIZE - 1] == FLAG_EOF);

        log("CLIENT_GBN", "RECV Data " + std::to_string(seqNum));

        if (seqNum == expectedSeqNum) {
            // (1) 期望的包
            log("CLIENT_GBN", "ACCEPT Data " + std::to_string(seqNum));
            
            // "将数据交给上层" (我们只打印)
            // std::string data(&recvBuffer[FRAME_HEADER_SIZE], DATA_PAYLOAD_SIZE); 
            // log("CLIENT_DATA", data.c_str());

            // 发送对该包的ACK
            sendAck(clientSocket, serverAddr, expectedSeqNum);
            
            // 期望的序列号+1 (由于 TOTAL_PACKETS < 255, 不处理回绕)
            expectedSeqNum++;

            if (isEof) {
                log("CLIENT", "Received EOF. GBN transfer complete.");
                break; // 结束GBN接收
            }
        } else {
            // (2) GBN特性：失序的包
            log("CLIENT_GBN", "DISCARD (Out of Order) Data " + std::to_string(seqNum) + ". Expected: " + std::to_string(expectedSeqNum));
            // 重新发送上一个成功接收的ACK
            if (expectedSeqNum > 0) {
                sendAck(clientSocket, serverAddr, expectedSeqNum - 1);
            }
            // (如果 expectedSeqNum=0, 还没收到过, 不发ACK)
        }
    }

    // GBN 结束后，恢复阻塞等待 (用于接收命令回复)
    setSocketTimeout(clientSocket, TIMEOUT_MS);
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        log("CLIENT_ERROR", "WSAStartup failed.");
        return 1;
    }

    SOCKET clientSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (clientSocket == INVALID_SOCKET) {
        log("CLIENT_ERROR", "Socket creation failed.");
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr); // 连接本地服务器

    // 默认超时 (用于等待命令回复)
    setSocketTimeout(clientSocket, TIMEOUT_MS);

    // 初始化随机数种子，用于模拟丢包
    srand(static_cast<unsigned int>(time(NULL)));

    std::string input;
    char responseBuffer[1024];

    while (true) {
        std::cout << "\n> ";
        std::getline(std::cin, input);
        if (input.empty()) continue;

        // 发送命令
        sendto(clientSocket, input.c_str(), input.length(), 0, (SOCKADDR*)&serverAddr, sizeof(serverAddr));

        if (input == "-quit") {
            log("CLIENT", "Quitting...");
            // (等待 "Good bye!" 回复)
        }

        // 等待服务器回复
        sockaddr_in fromAddr;
        int fromAddrLen = sizeof(fromAddr);
        int recvLen = recvfrom(clientSocket, responseBuffer, sizeof(responseBuffer) - 1, 0, (SOCKADDR*)&fromAddr, &fromAddrLen);

        if (recvLen == SOCKET_ERROR) {
            log("CLIENT_ERROR", "Server timed out.");
            continue;
        }
        
        responseBuffer[recvLen] = '\0';
        std::string response(responseBuffer);
        log("SERVER_REPLY", response);

        if (input == "-quit") {
            break; // 收到 "Good bye!" 后退出
        }

        // (-testgbn [X] [Y])
        if (input.rfind("-testgbn", 0) == 0) {
            // 解析 X 和 Y
            std::stringstream ss(input);
            std::string cmd, x_str, y_str;
            ss >> cmd >> x_str >> y_str;

            dataLossRate = x_str.empty() ? 0.2 : std::stod(x_str);
            ackLossRate = y_str.empty() ? 0.2 : std::stod(y_str);
            
            // 进入 GBN 接收状态
            startGbnReceive(clientSocket, serverAddr);
        }
    }

    closesocket(clientSocket);
    WSACleanup();
    return 0;
}