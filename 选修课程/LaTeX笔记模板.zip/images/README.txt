图片资源与开关

logo.png：从原离散数学笔记复制的校徽，默认显示在正文右上角。
mascot.png：原笔记的另一张小图，默认关闭。
background.jpg：原笔记的背景图，默认关闭；后续使用者可替换。
cover.pdf：不提供，由你后续自行放入；在主文件中取消 includepdf 的注释。

所有开关、路径、尺寸和背景透明度都在 settings.tex。
logo、mascot、background 三个开关相互独立。
支持 PNG、JPG、单页 PDF；保留原路径时直接替换文件即可。
默认只对正文及后续页面显示装饰，不影响封面与目录。
素材从原笔记复制，原文件未修改。
