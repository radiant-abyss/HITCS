param(
    [ValidateSet('main', 'start-here')]
    [string]$Target = 'main'
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = $PSScriptRoot
$BuildRoot = Join-Path $ProjectRoot 'build'
foreach ($Directory in @($BuildRoot, (Join-Path $BuildRoot 'chapters'), (Join-Path $BuildRoot 'templates'))) {
    New-Item -ItemType Directory -Path $Directory -Force | Out-Null
}
Push-Location -LiteralPath $ProjectRoot
try {
    for ($Pass = 1; $Pass -le 2; $Pass++) {
        & xelatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build "$Target.tex"
        if ($LASTEXITCODE -ne 0) {
            throw "XeLaTeX failed. Inspect build/$Target.log."
        }
    }
    Copy-Item -LiteralPath (Join-Path $BuildRoot "$Target.pdf") -Destination (Join-Path $ProjectRoot "$Target.pdf") -Force
    Write-Output "PDF ready: $(Join-Path $ProjectRoot "$Target.pdf")"
} finally {
    Pop-Location
}
