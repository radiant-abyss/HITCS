# LaTeX 中文笔记模板 v2

这一版参考现有离散数学笔记的源码与正文排版：连续正文、标准 amsthm 环境、正体内容、各类环境按节独立编号。保留深色标题、左右 3 cm 的版心和右上角校徽。默认没有封面，另一个小图与整页背景默认关闭。

## 从哪里开始

- main.tex / main.pdf：完整示例，包含集合与映射、数学证明、阅读记录和使用速查。
- start-here.tex / start-here.pdf：正式写作入口与三份空白骨架。
- **settings.tex：优先修改这个文件**，集中设置标题、作者、环境语言、图片与背景。
- notebook.sty：字体、版心、标题、编号和环境的样式定义。
- chapters/：示例；templates/：可复制的章节骨架；images/：图片资源。
- backups/v1-20261026.zip：本次修改前的完整第一版，仅本地保留，不放入新版发布包。

复制整个文件夹后，改 settings.tex，再填写 templates/。不需要的章节可以直接从主文件中删去对应 include 行。添加章节时复制文件并添加 include，复制后记得修改标签，避免重名。

## 校徽、小图和背景

在 settings.tex 中可以找到：

~~~latex
logo=true,
logo-file={images/logo.png},
logo-width=17mm,

mascot=false,
mascot-file={images/mascot.png},
mascot-width=17mm,

background=false,
background-file={images/background.jpg},
background-opacity=0.06
~~~

三个开关互相独立，true 为开启，false 为关闭。

- 校徽默认显示。其他学校的使用者可以替换 logo.png，或修改 logo-file。
- 右上角另一张小图默认关闭，需要时把 mascot 改为 true。它排列在校徽左侧。
- 背景默认关闭，需要时把 background 改为 true。
- **替换背景**：把自己的 JPG、PNG 或单页 PDF 放进 images/，将 background-file 改为新文件路径；也可以直接覆盖现有 background.jpg。
- 背景按比例缩放，居中放置；background-opacity 取 0 到 1，越小越淡。
- corner-top / corner-right 控制角落图片距纸张顶边、右边的距离。默认校徽尺寸与页眉留白已检查。
- 图片文件找不到时会跳过该图；导言区启用的缺失图片会给出日志警告，正文仍可编译。
- 这些装饰默认从主文件的 notebody 开始显示，不覆盖封面与目录。若要停止装饰，在需要的位置先 clearpage，再执行 notedecorationsoff。

logo.png、mascot.png 和 background.jpg 均从原离散数学笔记的素材目录复制。原笔记与原素材没有修改。

## 和原离散数学笔记相同的环境语法

~~~latex
\begin{definition}[定义标题]
  \label{def:my-definition}
  写定义。
\end{definition}

\begin{theorem}[定理标题]
  \label{thm:my-theorem}
  写结论。
\end{theorem}

\begin{proof}
  写证明。
\end{proof}

\begin{remark}[补充说明]
  写自己的理解、易错点或反例。
\end{remark}

由定义~\ref{def:my-definition} 和定理~\ref{thm:my-theorem} 可知……
~~~

标题放在方括号中，可以不写。标签放在环境正文里，名称自定，只需全文唯一。

每一类环境单独按节计数：同一小节里可以同时有 Definition 1.1.1、Theorem 1.1.1、Remark 1.1.1。这与原离散数学笔记一致。公式也按节编号，使用 eqref 引用。

| 环境 | 用途 |
| --- | --- |
| definition / theorem / lemma | 定义、定理、引理 |
| proposition / corollary | 命题、推论 |
| example / exercise | 例题、练习 |
| remark / reremark | 注、再注 |
| proof / ap | 证明、另一种证明 |
| solution / sol / analysis | 解答、分析；sol 是 solution 的别名 |
| algorithm | 算法说明 |

definition、theorem、lemma、proposition、corollary、example、exercise、remark 提供带星号的不编号版本，如 theorem*；仍使用方括号标题。

proof 会添加证毕符号。solution、sol、analysis、ap 是和原笔记相近的正文环境，不自动添加证毕符号。ap 若需要证毕符号，可在末尾加 \qed。未完成的证明请使用普通段落并明确注明缺口。

settings.tex 中默认 language=english，显示 Definition / Theorem / Remark；设为 language=chinese 可显示定义 / 定理 / 注，并使用中文章名。

**从第一版迁移**：第一版的 \begin{theorem}{标题}{标签} 已改为标准写法 \begin{theorem}[标题]\label{thm:标签}。包内示例和空白骨架已经全部迁移。

原离散笔记中的上述普通环境段落可以直接沿用；整份旧导言区不要重复粘贴。特殊宏包、自定义命令或原笔记中特定课程的专用环境仍需按实际内容补充。

## 课程、数学与阅读

三个骨架分别位于 templates/course.tex、templates/math.tex、templates/reading.tex。

课程章节保留“概念与结论 → 例题与分析 → 解答与易错点 → 课后整理”；数学章节保留“假设 → 定理 → 证明 → 反例与推广”；阅读章节保留“阅读信息 → 原文 → 自己的理解 → 评价与行动”。

原文摘录使用 excerpt，阅读信息使用：

~~~latex
\readinginfo{题名}{作者}{年份}{出处、页码或 \url{https://example.com}}
~~~

keyidea、intuition、pitfall、questionbox、notebox 现在都是轻量正文提示，不带彩色卡片。reviewitem 用于可手动勾选的检查条目。少数真正需要突出的结论可以用 focusbox。

main.tex 的参考文献条目是明确标注的格式占位，正式使用时替换成真实来源。start-here.tex 中的文献列表默认注释；启用后用 \cite{条目键} 引用。当前使用 thebibliography，不需要 Biber。

## 封面

封面仍由你自行插入。把封面 PDF 放进 images/cover.pdf，取消主文件中的这行注释：

~~~latex
\includepdf[pages=-,pagecommand={}]{images/cover.pdf}
~~~

也可以在同一位置写 \input{cover}。此时 cover.tex 只包含封面正文，不要再写 documentclass 或 document 环境。

## 编译

选择 **XeLaTeX**，需要 ctex、Fandol、Latin Modern、TeX Gyre、unicode-math、tcolorbox 等常用包与字体。项目里按字体文件名加载，不依赖特定 Windows 字体。

在项目文件夹中执行：

~~~powershell
.\build.ps1 -Target main
.\build.ps1 -Target start-here
~~~

脚本运行两遍 XeLaTeX，辅助文件写入 build/，成品 PDF 复制到项目根目录。也可在编辑器中编译两遍，或执行：

~~~text
latexmk -xelatex main.tex
latexmk -xelatex start-here.tex
~~~

用于 Overleaf 时上传整个项目，选择 XeLaTeX，并设置 main.tex 或 start-here.tex 为主文件。

## 改版式

主文件默认 zihao=5，接近原笔记的紧凑正文；若想更大，可以改成 zihao=-4。页边距与行距在 notebook.sty 中修改。

默认 \usepackage[academic]{notebook}；若要把标题与链接改为黑灰，使用 monochrome。该选项不改变图片颜色；纯白底打印时关闭 background 和 mascot，是否保留彩色校徽由 logo 单独控制。

图形可用 graphicx、TikZ；表格可用 tabularx、longtable；代码块用 listings。复杂推导用 align。普通英文代码可直接放入代码块，中文说明建议写在正文中。
